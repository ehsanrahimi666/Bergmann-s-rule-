# Bees (Anthophila): body size, hair, lightness and structural colour along latitude — data and code package

This package accompanies the manuscript "Poleward Increases in Bee Assemblage Body Size and Hairiness Are Carried by Bumblebees, While Structural Colour Declines" (project *Macroecology of pollinator colour, pattern and morphology*). The study is biogeographic only: it contains no species distribution models and no temporal trends. The package holds the manuscript, the analysis code, the analysis-ready data and the Supporting Information tables and figures.

## Contents
- **`manuscript.docx`** and **`manuscript.pdf`**: the manuscript, with Appendix S1 (Figures S1–S5 and Tables S3–S5 and S7–S9) at the end. Tables S1, S2 and S6 are CSV files only (`supplementary/`).
- **`code/`**
  - `README_code.md`: inputs, run order, settings and software versions.
  - `analysis_bees_final.py`: name matching, species table and all models.
  - `build_shared_inputs.py`: rebuilds the WorldClim 0.5° cell climate grid (not redistributable) and the species latitude and climate summaries.
  - `figures_tables_bees.py`: figures and display tables.
  - `table1_package_bees.py`: Table 1 and the `code/` and `data/` folders of this package.
  - `key_numbers.py`: prints key model rows at full precision.
  - `test_toolkit.py` and `toolkit_tests.csv`: tests of the toolkit on simulated data with known answers (32 of 32 pass).
  - `pmla_common.py`: shared toolkit (names, equal-area grid, assemblages, PGLS, SAR).
  - `gbif_id_cache.json`: GBIF species-API responses for the usage keys of the Ostwald et al. (2024) records (for `--offline` runs).
- **`data/`**
  - `species_traits_latitude_climate_analysed.csv`: one row per analysed species (≥3 occupied 0.5° cells) with every trait and its source columns, the ITD source string, latitude (median, mid-range, 5–95% quantiles, hemisphere share, median longitude), range-mean climate (bio1, bio4, bio5, bio12, bio15), lifestyle class, *Psithyrus* and introduced flags and whether the species is in the tree.
  - `species_traits_all_matched.csv`: the same columns for every matched species, including those with fewer than 3 cells.
  - `species_latitude_climate_analysed_species.csv`: species latitude and climate summaries for the analysed species.
  - `species_env_bees.csv`: species latitude and climate summaries for all 13,937 GBIF species (input of `analysis_bees_final.py`).
  - `cube_bees.parquet`: GBIF species × 0.5° cell record counts (input of `analysis_bees_final.py`).
  - `ne_110m_land.geojson`: Natural Earth land polygons (input of the map figures).
  - `assemblage_cells_*.csv`: 110-km Behrmann cells for each trait and scenario: cell id, centroid, number of GBIF species, number with trait data, coverage, trait mean and SD, *Bombus* shares and cell climate.
  - `assemblage_cells_ITD_bombus_decomposition.csv`: the 3,177 cells with ≥5 non-*Bombus* ITD species, with all-bee, non-*Bombus* and *Bombus* mean ITD.
  - `ostwald2025_specimens_with_climate.csv`: the imaged specimens with corrected coordinates and 0.5° cell climate.
  - Name matching: `name_matching_by_source.csv`, `name_matching_ostwald2024.csv` (verbatim name, GBIF usage key, both resolutions and the final choice), `name_matching_henriquezpiskulich2026.csv`, `ostwald2024_name_key_conflicts.csv`, `tree_tip_matching.csv`.
  - `bee_tree_pruned_analysed_species.nwk`: the chronogram pruned to the analysed species, with tips renamed to GBIF names.
  - Summaries: `analysed_species_by_trait.csv`, `trait_source_agreement.csv`, `assemblage_coverage.csv`, `aic_latitude_vs_climate.csv`, `tree_info.json`, `specimen_info.json`.
- **`supplementary/`**
  - `TableS1_all_models_full_precision.csv`: all 783 fitted models at full precision.
  - `TableS2_assemblage_coverage.csv`: coverage and composition of assemblage cells.
  - `TableS3_nonlinearity_hemispheres.csv`: quadratic terms, hemisphere subsets and interactions.
  - `TableS4_AIC_latitude_vs_climate.csv`: ΔAIC of latitude and climate predictor sets on identical rows.
  - `TableS5_ITD_sensitivity.csv`: sensitivity of the ITD–latitude slopes.
  - `TableS6_family_genus_lifestyle_all.csv`: family, genus, lifestyle and sociality models.
  - `TableS7_Bombus.csv`: models with and without *Bombus*.
  - `TableS8_structural_colour.csv`: structural colour models.
  - `TableS9_specimen_lightness_pilosity.csv`: specimen-level models.
  - `FigS1.png`–`FigS5.png` (300 dpi).
  - `main_Table1–4_*.csv`: the main tables; `data_*.csv`: copies of the name-matching and source-agreement summaries.

## Data sources
Licences are given as stated by the providers. Cite the original works when reusing their data.

| Data | Reference | DOI | Licence |
|---|---|---|---|
| GBIF occurrence download (seven bee families, 0.5° grid) | GBIF.org (2026) | 10.15468/dl.km56rh | CC BY-NC 4.0 |
| WorldClim 2.1 bioclimatic variables (5′, 1970–2000) | Fick & Hijmans (2017) | 10.1002/joc.5086 | free for academic and other non-commercial use; redistribution not allowed without permission (WorldClim terms) |
| EuPollTrait: traits of 3,000 European wild bee and hoverfly species | Miličić et al. (2026) | 10.1038/s41597-026-07513-8 (data 10.5281/zenodo.18032357) | CC BY 4.0 |
| BeeFunc: trait database for French bees | Aubouin et al. (2025) | 10.1038/s41597-025-05626-0 (data 10.48579/PRO/TYKGVC) | see source |
| Bee functional-trait compilation (morphology) | Ostwald et al. (2024); Zenodo v1.3.0 | 10.5281/zenodo.13366989 | MIT |
| pollimetry specimen data | Kendall et al. (2019) | 10.1002/ece3.4835 (code 10.5281/zenodo.1313905) | see repository |
| Structural colour in bees (data and code) | Henríquez-Piskulich et al. (2026) | 10.5061/dryad.h70rxwdwq | CC0 |
| Pilosity and lightness of imaged bees | Ostwald et al. (2025); Zenodo record | 10.5281/zenodo.15213039 | CC BY 4.0 |
| Supermatrix phylogeny of the world's bees (chronogram) | Henríquez-Piskulich et al. (2024); Dryad | 10.5061/dryad.80gb5mkw1 | CC0 |
| Discover Life bee checklist (BeeBDC taxonomy, TSV) | Ascher & Pickering (2022); Dorey et al. (2023); Zenodo copy by Poelen & Seltmann (2024) | 10.5281/zenodo.10463762 | CC0 |
| Natural Earth 1:110m land | naturalearthdata.com | — | public domain |

Every DOI above was resolved on 2026-09-30, and its title and authors were checked against the dataset; licences come from the Zenodo, DataCite, Dryad or provider metadata. The derived tables in `data/` inherit the terms of their sources; tables derived from the GBIF download are under CC BY-NC 4.0.

## Reproduce
1. Download the source data (table above) into DATA with the folder and file names listed in the header of `code/analysis_bees_final.py`, and the WorldClim 2.1 bioclimatic variables at 5′.
2. Follow `code/README_code.md`: rebuild the cell climate grid with `build_shared_inputs.py`, assemble the SHARED folder from `code/` and `data/`, and run `analysis_bees_final.py` with `--offline`, then the figure and table scripts.

The GBIF grid table is included, so no new GBIF download is needed. Run from this package with the rebuilt climate grid (checked 2026-09-30), the analysis reproduced all 783 models of Table S1 to within the float32 rounding of the climate grid (largest difference in any p-value 5 × 10⁻⁷; no value changed at the precision shown in the manuscript), the display tables were identical, and the figures were identical or differed in fewer than 0.01% of pixels. The run took 3–9 minutes on 2 CPU cores.
