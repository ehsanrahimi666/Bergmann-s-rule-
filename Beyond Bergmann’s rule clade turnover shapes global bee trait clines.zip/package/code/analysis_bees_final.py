#!/usr/bin/env python3
"""analysis_bees_final.py -- verified final analysis for the BEE manuscript (Anthophila):
body size (ITD, body length), pilosity, lightness, hairiness and structural colour vs absolute latitude.

Supersedes the first-pass script (results/bees/code/analysis_bees.py); every change is listed in
RESULTS_BRIEF.md -> 'Verification log'. Biogeography only (no SDMs, no temporal trends).

Run:  python3 analysis_bees_final.py [--data DATA] [--shared SHARED] [--out OUT] [--offline]
      (then figures_tables_bees.py builds figures/, tables/ and package/supplementary/)
Inputs (DATA = <project>/bees/data; see package/README.md for DOIs and licences):
  Ostwald_2024_bee_morphological_traits/Sup Table 4 Morphological Dataset Revised.csv
  Ostwald_2025_bee_pilosity_lightness_images/pilosity_lightness_data.csv
  HenriquezPiskulich_2026_bee_structural_colour/env_data.csv, bee_f_size.csv
  HenriquezPiskulich_2024_world_bee_supermatrix_phylogeny_files/BEE_mat7_fulltree_tplo35_sf20lp.nwk
  DiscoverLife_world_bee_checklist/bee-taxonomy.tsv
  Kendall_2019_pollimetry_package/pollimetry_1.0.1/pollimetry/data/pollimetry_dataset.rdata
  _from_library/Milicic_2026_EuPollTrait_European_bee_hoverfly_traits/input/trait_data_input.csv
  _from_library/Aubouin_2025_BeeFunc_French_bee_traits/BeeFuncITD.csv, BeeFuncSociality.csv
SHARED = pmla_common.py, species_env_bees.csv, cube_bees.parquet, cell_climate_0.5deg.parquet
GBIF species-API cache for the Ostwald 2024 usage keys: <OUT>/gbif_id_cache.json (use --offline to run from it).
"""
import os, sys, re, json, argparse, time, warnings
import numpy as np, pandas as pd
warnings.filterwarnings('ignore')
HERE = os.path.dirname(os.path.abspath(__file__))
DEF = dict(data='/mnt/user-data/uploads/global dataset/PROJECT_POLLINATOR_MORPHOLOGY_LATITUDE/bees/data',
           shared='/home/claude/pmla/shared', out=os.path.join(HERE, 'results'))
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    for k, v in DEF.items(): ap.add_argument('--' + k, default=v)
    ap.add_argument('--offline', action='store_true')
    ARGS = ap.parse_args()
else:
    ARGS = argparse.Namespace(**DEF, offline=True)
sys.path.insert(0, ARGS.shared)
import pmla_common as pc
pc.SHARED = os.path.abspath(ARGS.shared)  # the toolkit reads cube, species_env and cell climate from --shared (its default is the container path)
import statsmodels.formula.api as smf
import statsmodels.api as sm
from scipy import stats

GROUP = 'bees'
SEED = 20260930
np.random.seed(SEED)
T0 = time.time()
def log(*a): print(f'[{time.time()-T0:6.0f}s]', *a, flush=True)

INTRODUCED = ['Apis mellifera', 'Apis cerana', 'Bombus terrestris', 'Bombus ruderatus', 'Bombus hortorum',
              'Bombus subterraneus', 'Megachile rotundata', 'Megachile sculpturalis', 'Megachile apicalis',
              'Megachile concinna', 'Megachile lanata', 'Anthidium manicatum', 'Anthidium oblongatum',
              'Osmia cornifrons', 'Osmia taurus', 'Andrena wilkella', 'Chelostoma campanularum',
              'Hylaeus leptocephalus', 'Hylaeus hyalinatus', 'Hylaeus punctatus', 'Halictus tectus',
              'Nomia melanderi', 'Anthophora villosula', 'Pseudoanthidium nanum', 'Ceratina dallatorreana',
              'Lithurgus chrysurus', 'Euglossa dilemma', 'Braunsapis puangensis']
PSITHYRUS = {'vestalis', 'bohemicus', 'barbutellus', 'campestris', 'rupestris', 'sylvestris', 'norvegicus',
             'flavidus', 'quadricolor', 'insularis', 'citrinus', 'variabilis', 'suckleyi', 'fernaldae', 'ashtoni',
             'maxillosus', 'perezi', 'skorikovi', 'chinensis', 'turneri', 'coreanus', 'novus', 'tibetanus',
             'branickii', 'morawitzi', 'cornutus', 'expolitus', 'ferganicus', 'klapperichi', 'monozonus'}
EUSOCIAL_TRIBES = {'Apini', 'Meliponini', 'Bombini'}
PARASITIC_TRIBES = {'Nomadini', 'Epeolini', 'Ammobatini', 'Melectini', 'Ericrocidini', 'Osirini', 'Brachynomadini',
                    'Ammobatoidini', 'Neolarrini', 'Dioxyini', 'Protepeolini', 'Isepeolini', 'Rhathymini',
                    'Hexepeolini', 'Townsendiellini', 'Biastini', 'Caenoprosopidini'}
PARASITIC_GENERA = {'Sphecodes', 'Coelioxys', 'Stelis', 'Hoplostelis', 'Euaspis', 'Thyreus', 'Aglaoapis',
                    'Radoszkowskiana', 'Dioxys', 'Pseudodichroa', 'Microsphecodes', 'Eupetersia', 'Nesosphecodes',
                    'Ptilocleptis', 'Paralictus', 'Temnosoma', 'Exaerete', 'Aglae', 'Hypotrigona_x'}
FAMILIES = ['Apidae', 'Halictidae', 'Andrenidae', 'Megachilidae', 'Colletidae', 'Melittidae']
REGIONS = {  # (lon_min, lon_max, lat_min, lat_max) on range medians / cell centroids
    'W Palaearctic': (-25, 60, 25, 72), 'Nearctic': (-170, -50, 23.44, 75), 'Neotropics': (-120, -30, -60, 23.44),
    'Tropics (|lat|<23.4)': (-180, 180, -23.44, 23.44), 'Southern Hemisphere': (-180, 180, -90, 0)}

P = dict(
    ost24=('Ostwald_2024_bee_morphological_traits', 'Sup Table 4 Morphological Dataset Revised.csv'),
    ost25=('Ostwald_2025_bee_pilosity_lightness_images', 'pilosity_lightness_data.csv'),
    hp_env=('HenriquezPiskulich_2026_bee_structural_colour', 'env_data.csv'),
    hp_size=('HenriquezPiskulich_2026_bee_structural_colour', 'bee_f_size.csv'),
    tree=('HenriquezPiskulich_2024_world_bee_supermatrix_phylogeny_files', 'BEE_mat7_fulltree_tplo35_sf20lp.nwk'),
    dl=('DiscoverLife_world_bee_checklist', 'bee-taxonomy.tsv'),
    ken=('Kendall_2019_pollimetry_package', 'pollimetry_1.0.1', 'pollimetry', 'data', 'pollimetry_dataset.rdata'),
    eupoll=('_from_library', 'Milicic_2026_EuPollTrait_European_bee_hoverfly_traits', 'input', 'trait_data_input.csv'),
    beefunc=('_from_library', 'Aubouin_2025_BeeFunc_French_bee_traits', 'BeeFuncITD.csv'),
    beefunc_soc=('_from_library', 'Aubouin_2025_BeeFunc_French_bee_traits', 'BeeFuncSociality.csv'))
P = {k: os.path.join(ARGS.data, *v) for k, v in P.items()}
OUT = ARGS.out
DATA_OUT = os.path.join(OUT, 'data')

# =============================================================== helpers
def rd(f, sep=','):
    for enc in ('utf-8', 'cp1252', 'latin-1'):
        try: return pd.read_csv(f, sep=sep, encoding=enc, low_memory=False)
        except UnicodeDecodeError: continue
    raise IOError(f)

def num(x):
    return pd.to_numeric(pd.Series(x).astype(str).str.replace(',', '.', regex=False).str.strip(), errors='coerce').values

def load_dl(path):
    d = pd.read_csv(path, sep='\t', usecols=['taxonomic_status', 'accid', 'id', 'canonical', 'family', 'tribe', 'genus'], low_memory=False)
    d['bin'] = d.canonical.map(pc.clean_name)
    acc = d[d.taxonomic_status == 'accepted'].set_index('id')['bin']
    accepted = set(acc.dropna())
    syn = d[d.taxonomic_status == 'synonym'].copy(); syn['acc_bin'] = syn.accid.map(acc)
    syn = syn.dropna(subset=['bin', 'acc_bin']); syn = syn[syn.bin != syn.acc_bin]
    k = syn.groupby('bin').acc_bin.nunique(); syn = syn[syn.bin.isin(k[k == 1].index)].drop_duplicates('bin')
    s2a = {b: a for b, a in zip(syn.bin, syn.acc_bin) if b not in accepted}
    tribe_g = d[d.taxonomic_status == 'accepted'].dropna(subset=['genus', 'tribe']).groupby('genus').tribe.agg(lambda s: s.mode().iat[0])
    return accepted, s2a, tribe_g.to_dict()

class Matcher:
    """trait name -> GBIF cube species: exact; else Discover Life synonym -> accepted name in GBIF; else a unique GBIF
    name whose Discover Life accepted name equals the trait name's accepted name."""
    def __init__(self, gbif_names, s2a):
        self.g = set(gbif_names); self.s2a = s2a; self.km = {}
        for n in gbif_names: self.km.setdefault(s2a.get(n, n), set()).add(n)
    def __call__(self, name):
        n = pc.clean_name(name)
        if n is None: return None, 'unparsable'
        if n in self.g: return n, 'exact'
        k = self.s2a.get(n, n)
        if k in self.g: return k, 'synonym'
        c = self.km.get(k, set())
        return (next(iter(c)), 'synonym') if len(c) == 1 else (None, 'unmatched')

def gbif_resolve(ids, cache_path, offline=False):
    cache = json.load(open(cache_path)) if os.path.exists(cache_path) else {}
    todo = [i for i in ids if str(i) not in cache]
    if todo and not offline:
        import urllib.request
        from concurrent.futures import ThreadPoolExecutor
        def get(k):
            for attempt in range(4):
                try:
                    with urllib.request.urlopen(f'https://api.gbif.org/v1/species/{k}', timeout=30) as r: j = json.load(r)
                    return str(k), {'rank': j.get('rank'), 'species': j.get('species'), 'status': j.get('taxonomicStatus'), 'canonical': j.get('canonicalName')}
                except Exception: time.sleep(1.5 * (attempt + 1))
            return str(k), None
        with ThreadPoolExecutor(4) as ex:
            for k, v in ex.map(get, todo):
                if v is not None: cache[k] = v
        json.dump(cache, open(cache_path, 'w'))
    return cache

# ---------------------------------------------------------------- model helpers
def ci(est, se, df=None, level=0.95):
    q = stats.t.ppf(0.5 + level / 2, df) if df else stats.norm.ppf(0.5 + level / 2)
    return est - q * se, est + q * se

def zfac(x, y):
    sx, sy = np.nanstd(np.asarray(x, float), ddof=1), np.nanstd(np.asarray(y, float), ddof=1)
    return sx / sy if sy > 0 else np.nan

def fit_ols(d, y, xs):
    return smf.ols(f'{y} ~ ' + ' + '.join(xs), d).fit()

def fit_lmm(d, y, xs, fam=True, reml=True):
    """Genus random intercept (+ family fixed effects). Tries lbfgs, then powell, nm, bfgs; accepts the first fit that
    converged with finite SEs for xs. Returns (result, method, note)."""
    f = f'{y} ~ ' + ' + '.join(xs) + (' + C(family)' if fam and d.family.nunique() > 1 else '')
    md = smf.mixedlm(f, d, groups=d['genus'])
    last = None
    for method in ('lbfgs', 'powell', 'nm', 'bfgs'):
        try:
            m = md.fit(reml=reml, method=method, maxiter=5000)
            last = (m, method)
            if m.converged and all(np.isfinite(m.bse.get(x, np.nan)) for x in xs):
                return m, method, ''
        except Exception as e:
            continue
    if last is not None:
        return last[0], last[1], 'not converged'
    return None, None, 'failed'

_TREE_NAMES, _VCV = {}, {}
def register_tree(tree):
    _TREE_NAMES[id(tree)] = {pc.clean_name(l.taxon.label) for l in tree.leaf_node_iter()}

def _vcv_eig(tree, names_set):
    key = (id(tree), frozenset(names_set))
    if key not in _VCV:
        names, V = pc.tree_vcv(tree, set(names_set))
        V = V / np.diag(V).mean()
        ultra = np.max(np.abs(np.diag(V) - 1)) < 1e-4
        ev, Q = np.linalg.eigh(V) if ultra else (None, None)
        while len(_VCV) >= 6: _VCV.pop(next(iter(_VCV)))
        _VCV[key] = (names, V, ultra, ev, Q)
    return _VCV[key]

def pgls_fast(df, y, xs, tree, species_col='species', lambdas=np.linspace(0, 1, 21)):
    """Pagel-lambda PGLS by ML; same likelihood, estimates and SEs as pmla_common.pgls (tested in test_toolkit.py).
    For an ultrametric tree C(lambda) = lambda*V + (1-lambda)*I shares V's eigenvectors, so each lambda is O(n)."""
    d = df.dropna(subset=[y] + xs).drop_duplicates(species_col).set_index(species_col)
    names, V, ultra, ev, Q = _vcv_eig(tree, set(d.index) & _TREE_NAMES[id(tree)])
    if not ultra: return pc.pgls(df, y, xs, tree, species_col)
    d = d.loc[names]; Y = d[y].values.astype(float)
    X = np.column_stack([np.ones(len(d))] + [d[x].values.astype(float) for x in xs]); n, p = X.shape
    Xq, Yq = Q.T @ X, Q.T @ Y
    def fit(lam):
        w = np.clip(lam * ev + (1 - lam), 1e-12, None)
        Xw = Xq / np.sqrt(w)[:, None]; Yw = Yq / np.sqrt(w)
        b, *_ = np.linalg.lstsq(Xw, Yw, rcond=None); r = Yw - Xw @ b
        s2 = r @ r / n; ll = -0.5 * (n * np.log(2 * np.pi * s2) + np.sum(np.log(w)) + n)
        cov = np.linalg.inv(Xw.T @ Xw) * (r @ r / (n - p))
        return ll, b, cov
    res = [(lam, *fit(lam)) for lam in lambdas]
    best = max(res, key=lambda t: t[1]); lam0 = best[0]
    for lam in np.clip(np.linspace(lam0 - 0.05, lam0 + 0.05, 11), 0, 1):
        r_ = (lam, *fit(lam))
        if r_[1] > best[1]: best = r_
    lam, ll, b, cov = best; se = np.sqrt(np.diag(cov)); t = b / se; pv = 2 * stats.t.sf(np.abs(t), n - p)
    ll0 = fit(0.0)[0]; ll1 = fit(1.0)[0]
    tab = pd.DataFrame({'term': ['Intercept'] + xs, 'estimate': b, 'se': se, 't': t, 'p': pv})
    return {'table': tab, 'lambda': float(lam), 'logLik': float(ll), 'n': int(n), 'df': n - p,
            'LR_lambda_vs_0': float(2 * (ll - ll0)), 'LR_lambda_vs_1': float(2 * (ll - ll1)), 'k': p + 2}

def sar_error_lu(df, y, xs, k=8):
    """ML spatial-error SAR, k-nearest-neighbour (k=8) row-standardised weights on Behrmann x/y (km). Same likelihood
    as pmla_common.sar_error (spreg ML_Error); log|I - lam W| from a sparse LU (tested in test_toolkit.py).
    Also returns Moran's I of the SAR (spatially filtered) residuals."""
    import libpysal, scipy.sparse as sp
    from scipy.sparse.linalg import splu
    from scipy.optimize import minimize_scalar
    from esda.moran import Moran
    d = df.dropna(subset=[y] + xs).copy(); n = len(d)
    x_, y_ = pc.behrmann_xy(d.lat.values, d.lon.values)
    w = libpysal.weights.KNN(np.column_stack([x_, y_]), k=k); w.transform = 'r'
    W = w.sparse.tocsc(); I = sp.identity(n, format='csc')
    Y = d[y].values.astype(float); X = np.column_stack([np.ones(n)] + [d[c].values.astype(float) for c in xs])
    WY, WX = W @ Y, W @ X
    bo, *_ = np.linalg.lstsq(X, Y, rcond=None); uo = Y - X @ bo
    r2o = 1 - uo @ uo / np.sum((Y - Y.mean()) ** 2)
    mi = Moran(uo, w, permutations=0)
    def conc(lam):
        ys, Xs = Y - lam * WY, X - lam * WX
        b, *_ = np.linalg.lstsq(Xs, ys, rcond=None); e = ys - Xs @ b
        lu = splu((I - lam * W).tocsc())
        logdet = np.sum(np.log(np.abs(lu.U.diagonal()))) + np.sum(np.log(np.abs(lu.L.diagonal())))
        return n / 2 * np.log(e @ e / n) - logdet
    res = minimize_scalar(conc, bounds=(-0.999, 0.999), method='bounded', options={'xatol': 1e-7})
    lam = float(res.x)
    ys, Xs = Y - lam * WY, X - lam * WX
    XtX_i = np.linalg.inv(Xs.T @ Xs); b = XtX_i @ Xs.T @ ys; e = ys - Xs @ b; s2 = e @ e / n
    se = np.sqrt(np.diag(s2 * XtX_i)); z = b / se; pv = 2 * stats.norm.sf(np.abs(z))
    ll = -res.fun - n / 2 * np.log(2 * np.pi) - n / 2
    pr2 = np.corrcoef(Y, X @ b)[0, 1] ** 2
    mi_sar = Moran(e, w, permutations=0)
    tab = pd.DataFrame({'term': ['CONSTANT'] + xs, 'estimate': b, 'se': se, 'z': z, 'p': pv})
    return {'table': tab, 'lambda': lam, 'aic': float(2 * (X.shape[1] + 2) - 2 * ll), 'pseudo_r2': float(pr2), 'n': n,
            'ols_r2': float(r2o), 'moran_I_ols_resid': float(mi.I), 'moran_p': float(mi.p_norm), 'logLik': float(ll),
            'moran_I_sar_resid': float(mi_sar.I), 'moran_p_sar': float(mi_sar.p_norm)}

# ---------------------------------------------------------------- result collector
ROWS = []
LOGT = {'log_itd', 'log_blen', 'log_hairiness_eu'}
def add_row(level, trait, subset, model, predictor, term, n, est, se, p, df=None, x=None, yv=None, **kw):
    lo, hi = ci(est, se, df) if np.isfinite(se) else (np.nan, np.nan)
    r = dict(level=level, trait=trait, subset=subset, model=model, predictor=predictor, term=term, n=n, estimate=est, se=se,
             ci_lo=lo, ci_hi=hi, p=p)
    per = 10.0 if term in ('abslat', 'abslat_median', 'abslat_c') else 1.0
    r['unit'] = 'per 10 deg |lat|' if per == 10 else ('per 1 degC' if term in ('bio1', 'bio1_mean', 'bio5', 'bio5_mean') else 'per unit')
    r['slope_unit'] = est * per; r['se_unit'] = se * per; r['ci_lo_unit'] = lo * per; r['ci_hi_unit'] = hi * per
    if trait in LOGT and term in ('abslat', 'abslat_median', 'abslat_c', 'bio1', 'bio1_mean', 'bio5'):
        r['pct_change_unit'] = 100 * (10 ** (est * per) - 1)
        r['pct_ci_lo'] = 100 * (10 ** (lo * per) - 1); r['pct_ci_hi'] = 100 * (10 ** (hi * per) - 1)
    if x is not None and yv is not None: r['std_effect'] = est * zfac(x, yv)
    r.update(kw); ROWS.append(r); return r

# =============================================================== data
def load_sources(match, cov_rows, conflicts):
    S = {}
    def attach(df, name_col, src, n_rec):
        m = df[name_col].map(match)
        df = df.assign(species=[x[0] for x in m], how=[x[1] for x in m])
        u = df.drop_duplicates(name_col)
        cov_rows.append(dict(source=src, n_records=n_rec, n_names=len(u), matched_exact=int((u.how == 'exact').sum()),
                             matched_synonym=int((u.how == 'synonym').sum()), unmatched=int((u.how == 'unmatched').sum()),
                             unparsable=int((u.how == 'unparsable').sum()), n_gbif_species=int(df.species.nunique()),
                             n_names_merged_into_shared_species=int(len(u.dropna(subset=['species'])) - u.species.nunique())))
        return df.dropna(subset=['species'])
    # 1 EuPollTrait: female ITD (workers for eusocial species; queens separate and almost never given), hairiness F
    e = rd(P['eupoll']); e = e[e.Order == 'Hymenoptera'].copy()
    e = pd.DataFrame({'name': e.Genus_and_species.values, 'itd_mm': num(e['ITD_(inter-tegular_distance)']),
                      'itd_n': num(e['ITD_(inter-tegular_distance).1']), 'hairiness_eu': num(e['Hairiness_index']),
                      'sociality': e['Sociality'].values})
    e = attach(e, 'name', 'EuPollTrait (Milicic et al. 2026): female/worker ITD, female hairiness index', len(e))
    S['eu'] = e.groupby('species', as_index=False)[['itd_mm', 'hairiness_eu']].mean()
    S['eu_soc'] = e.dropna(subset=['sociality']).drop_duplicates('species').set_index('species').sociality
    # 2 BeeFunc: sex/caste not recorded (e.g. Bombus terrestris 3.44 and 6.15 mm) -> fill-in only
    b = rd(P['beefunc'], ';'); b = pd.DataFrame({'name': b.LB_NOM.values, 'itd_mm': num(b.LENGTH)})
    b = attach(b.dropna(subset=['itd_mm']), 'name', 'BeeFunc (Aubouin et al. 2025): ITD, sex not recorded', len(b))
    S['bf'] = b.groupby('species', as_index=False).itd_mm.mean()
    bs = rd(P['beefunc_soc'], ';'); bs = pd.DataFrame({'name': bs.LB_NOM.values, 'soc': bs.SOCIABILITY.values})
    bs['species'] = [match(x)[0] for x in bs.name]
    S['bf_soc'] = bs.dropna(subset=['species']).drop_duplicates('species').set_index('species').soc
    # 3 Ostwald 2024 compilation: VERBATIM NAME FIRST, GBIF usage key only when the verbatim name does not match
    o = rd(P['ost24']); o['val'] = num(o.measurementValue)
    o['key'] = o.acceptedNameUsageID.astype(str).str.extract(r'(\d+)')[0]
    cache = gbif_resolve(sorted(o.key.dropna().unique()), os.path.join(OUT, 'gbif_id_cache.json'), ARGS.offline)
    def res_name(k):
        c = cache.get(str(k))
        return c['species'] if c and c.get('rank') in ('SPECIES', 'SUBSPECIES', 'VARIETY', 'FORM') and c.get('species') else None
    o['id_name'] = o.key.map(res_name)
    o['id_rank'] = o.key.map(lambda k: (cache.get(str(k)) or {}).get('rank'))
    mv = o.verbatimAcceptedNameUsage.map(match); mi = o.id_name.map(lambda s: match(s) if isinstance(s, str) else (None, 'none'))
    o['sp_v'] = [x[0] for x in mv]; o['sp_id'] = [x[0] for x in mi]
    o['id_name_c'] = o.id_name
    # the usage key is trusted only if it plausibly refers to the verbatim name (verbatim unparsable/abbreviated, or the
    # key's own canonical name or its accepted species has a near-identical epithet); keys in the compilation are
    # sometimes wrong (e.g. 'Perdita fallax' -> P. polita and P. zebrata; 'Bombus terricola' -> B. terrestris)
    from difflib import SequenceMatcher
    def ep(nm):
        c = pc.clean_name(nm) if isinstance(nm, str) else None
        return c.split()[1] if c else None
    o['canon'] = o.key.map(lambda k: (cache.get(str(k)) or {}).get('canonical'))
    def trusted(r):
        vb = str(r.verbatimAcceptedNameUsage)
        if re.search(r'\b(cf|cfr|aff|nr|near)\b\.?', vb, flags=re.I): return False      # uncertain identifications
        ev = ep(vb)
        if ev is None: return True
        vl = re.sub(r'[^a-z]', '', vb.lower())
        for other in (r.canon, r.id_name):
            eo = ep(other)
            if not eo: continue
            if SequenceMatcher(None, ev, eo).ratio() >= 0.75: return True             # spelling / gender-ending variants
            if len(eo) > 3 and re.sub(r'[^a-z]', '', eo) in vl: return True           # e.g. 'Andrena_w_scripta' -> 'w-scripta'
        return False
    o['key_trusted'] = [trusted(r) for r in o[['verbatimAcceptedNameUsage', 'canon', 'id_name']].itertuples()]
    o['species_final'] = o.sp_v.where(o.sp_v.notna(), o.sp_id.where(o.key_trusted))
    o.loc[o.id_rank.isin(['GENUS', 'FAMILY', 'TRIBE', 'SUBGENUS']) & o.sp_v.isna(), 'species_final'] = None
    o['how'] = np.where(o.sp_v.notna(), 'verbatim name', np.where(o.species_final.notna(), 'GBIF usage key',
                        np.where(o.sp_id.notna() & ~o.key_trusted, 'rejected: key conflicts with verbatim name', 'unmatched')))
    cf = o[(o.sp_v.notna()) & (o.sp_id.notna()) & (o.sp_v != o.sp_id)].drop_duplicates(['verbatimAcceptedNameUsage'])
    for r in cf.itertuples():
        conflicts.append(dict(source='Ostwald 2024', verbatim=r.verbatimAcceptedNameUsage, gbif_key=r.key, key_resolves_to=r.sp_id,
                              first_pass_used=r.sp_id, final_used=r.sp_v, type='verbatim and key match different GBIF species'))
    for r in o[o.sp_v.isna() & o.sp_id.notna() & ~o.key_trusted].drop_duplicates('verbatimAcceptedNameUsage').itertuples():
        conflicts.append(dict(source='Ostwald 2024', verbatim=r.verbatimAcceptedNameUsage, gbif_key=r.key, key_resolves_to=r.sp_id,
                              first_pass_used=r.sp_id, final_used=None, type='verbatim not in GBIF cube; key points to a different species (rejected)'))
    # first-pass assignment (key first) kept for the verification log
    o['species_firstpass'] = o.sp_id.where(o.sp_id.notna(), o.sp_v)
    sex = o.sex.fillna('unspecified').str.lower().str.strip()
    o['sex_class'] = np.select([sex.isin(['f', 'female']), sex.eq('female (assumed)'), sex.isin(['male', 'm', 'f/m']),
                                sex.isin(['queen']), sex.isin(['worker'])], ['female', 'female_assumed', 'male_or_mixed', 'queen', 'worker'], 'unknown')
    keep = (~o.sex_class.isin(['male_or_mixed', 'queen'])) & (o.valueSummary.astype(str).str.strip() != 'community-weighted mean')
    oi = o[keep & (o.measurementType == 'ITD') & o.val.between(0.2, 12)].copy()
    ob = o[keep & (o.measurementType == 'body length') & o.val.between(1, 45)].copy()
    for lab, df_, n_ in (('Ostwald et al. 2024 compilation: ITD', oi, len(oi)), ('Ostwald et al. 2024 compilation: body length', ob, len(ob))):
        u = df_.drop_duplicates('verbatimAcceptedNameUsage')
        cov_rows.append(dict(source=lab, n_records=n_, n_names=len(u), matched_exact=int((u.how == 'verbatim name').sum()),
                             matched_synonym=int((u.how == 'GBIF usage key').sum()), unmatched=int((u.how == 'unmatched').sum()),
                             unparsable=0, n_gbif_species=int(df_.species_final.nunique()),
                             n_names_merged_into_shared_species=int(len(u.dropna(subset=['species_final'])) - u.species_final.nunique()),
                             note='matched_exact = verbatim name (exact or Discover Life synonym); matched_synonym column = via GBIF usage key'))
    def study_mean(df_, col='species_final'):
        d_ = df_.dropna(subset=[col]).assign(lv=lambda z: np.log10(z.val))
        per = d_.groupby([col, 'associatedReferencesID']).lv.mean().reset_index()
        return per.groupby(col).lv.agg(['mean', 'size']).rename(columns={'mean': 'log', 'size': 'n_studies'})
    S['ost_itd'] = study_mean(oi); S['ost_itd_f'] = study_mean(oi[oi.sex_class == 'female'])
    S['ost_bl'] = study_mean(ob)
    S['ost_itd_firstpass_names'] = study_mean(oi, 'species_firstpass')
    S['ost_sexmix'] = oi.dropna(subset=['species_final']).groupby('species_final').sex_class.agg(lambda s: ';'.join(sorted(set(s))))
    S['ost_records'] = o
    # 4 Kendall 2019 pollimetry: female bee specimens (IT, BL in mm)
    import pyreadr
    k = list(pyreadr.read_r(P['ken']).values())[0]
    k = k[(k.Superfamily == 'Apoidea') & (k.Sex == 'Female')].copy(); k['name'] = k.Species.astype(str)
    k = attach(k, 'name', 'Kendall et al. 2019 pollimetry: female specimens', len(k))
    S['ken'] = k.groupby('species', as_index=False).agg(itd_mm=('IT', 'mean'), body_length_mm=('BL', 'mean'))
    # 5 Henriquez-Piskulich 2026: structural colour (either sex; female-only column too), female body length
    h = rd(P['hp_env']); hs = rd(P['hp_size'])
    h = h.merge(hs.rename(columns={'f_body_size_mm': 'f_bl2', 'struc_present': 'sp2'}), on='species', how='outer')
    h['body_length_mm'] = h.f_body_size_mm.fillna(h.f_bl2); h['struc_present'] = h.struc_present.fillna(h.sp2)
    m = h['species'].map(match); h['hp_name'] = h['species']; h['species'] = [x[0] for x in m]; h['how'] = [x[1] for x in m]
    cov_rows.append(dict(source='Henriquez-Piskulich et al. 2026: structural colour, female body length', n_records=len(h), n_names=len(h),
                         matched_exact=int((h.how == 'exact').sum()), matched_synonym=int((h.how == 'synonym').sum()),
                         unmatched=int((h.how == 'unmatched').sum()), unparsable=int((h.how == 'unparsable').sum()),
                         n_gbif_species=int(h.species.nunique()), n_names_merged_into_shared_species=int(h.species.notna().sum() - h.species.nunique())))
    S['hp_all'] = h
    hh = h.dropna(subset=['species'])
    S['hp'] = hh.groupby('species', as_index=False).agg(body_length_mm=('body_length_mm', 'mean'), struc_present=('struc_present', 'max'),
                                                         f_struc_present=('f_struc_present', 'max'))
    # 6 Ostwald 2025 imaged female specimens: lightness (median brightness, 0-255), pilosity (hair proportion)
    s = rd(P['ost25']); s['name'] = s.Genus_species.astype(str)
    s = attach(s, 'name', 'Ostwald et al. 2025: imaged female specimens (lightness, pilosity)', len(s))
    s['lightness'] = s['Brightness.Median']; s['pilosity'] = s['pilosity_proportion']
    S['ost25'] = s.groupby('species', as_index=False)[['lightness', 'pilosity']].mean()
    raw = rd(P['ost25']); raw['lightness'] = raw['Brightness.Median']; raw['pilosity'] = raw['pilosity_proportion']
    raw['species'] = raw.Genus_species.astype(str).str.replace('_', ' ')   # specimen models need no GBIF match
    S['ost25_spec'] = raw
    return S

def build_species_table(S, se, dl_tribe):
    t = se.copy()
    def add(df, col, new, key='species'):
        t[new] = t.species.map(df.set_index(key)[col] if key in df.columns else df[col]) if len(df) else np.nan
    add(S['eu'], 'itd_mm', 'itd_eu'); add(S['bf'], 'itd_mm', 'itd_bf'); add(S['ken'], 'itd_mm', 'itd_ken')
    t['log_itd_ost'] = t.species.map(S['ost_itd']['log']); t['n_studies_ost'] = t.species.map(S['ost_itd']['n_studies'])
    t['log_itd_ost_female'] = t.species.map(S['ost_itd_f']['log']); t['ost_sex_classes'] = t.species.map(S['ost_sexmix'])
    t['log_itd_ost_firstpass'] = t.species.map(S['ost_itd_firstpass_names']['log'])
    add(S['hp'], 'body_length_mm', 'bl_hp'); add(S['ken'], 'body_length_mm', 'bl_ken')
    t['log_bl_ost'] = t.species.map(S['ost_bl']['log'])
    add(S['eu'], 'hairiness_eu', 'hairiness_eu'); add(S['hp'], 'struc_present', 'struc'); add(S['hp'], 'f_struc_present', 'struc_female')
    add(S['ost25'], 'lightness', 'lightness'); add(S['ost25'], 'pilosity', 'pilosity')
    # ITD composite: mean of log10 source values; European value = EuPollTrait, BeeFunc only where EuPollTrait lacks it
    t['itd_euro'] = t.itd_eu.fillna(t.itd_bf)
    L = pd.DataFrame({'euro': np.log10(t.itd_euro), 'ost': t.log_itd_ost, 'ken': np.log10(t.itd_ken)})
    t['log_itd'] = L.mean(axis=1); t['n_itd_sources'] = L.notna().sum(axis=1)
    t['itd_sources'] = L.notna().apply(lambda r: '+'.join([c for c in L.columns if r[c]]), axis=1).replace('', np.nan)
    t.loc[t.itd_euro.notna() & t.itd_eu.isna(), 'itd_sources'] = t.itd_sources.str.replace('euro', 'beefunc')
    t.loc[t.itd_eu.notna(), 'itd_sources'] = t.itd_sources.str.replace('euro', 'eupolltrait')
    # females-only composite: EuPollTrait F, Ostwald records with sex = F/female, Kendall females (no BeeFunc, no unknown sex)
    Lf = pd.DataFrame({'eu': np.log10(t.itd_eu), 'ost': t.log_itd_ost_female, 'ken': np.log10(t.itd_ken)})
    t['log_itd_female'] = Lf.mean(axis=1)
    # first-pass composite with the key-first Ostwald names and raw-record means (for the verification log)
    t['log_itd_firstpass_names'] = pd.DataFrame({'euro': np.log10(t.itd_euro), 'ost': t.log_itd_ost_firstpass, 'ken': np.log10(t.itd_ken)}).mean(axis=1)
    Lb = pd.DataFrame({'hp': np.log10(t.bl_hp), 'ken': np.log10(t.bl_ken), 'ost': t.log_bl_ost})
    t['log_blen'] = Lb.mean(axis=1)
    t['log_hairiness_eu'] = np.log10(t.hairiness_eu.where(t.hairiness_eu > 0))
    t['introduced'] = t.species.isin(INTRODUCED)
    eusoc = t.species.map(S['eu_soc'])
    t['psithyrus'] = (t.genus == 'Bombus') & (t.species.str.split().str[1].isin(PSITHYRUS) | eusoc.isin(['obligate_inquiline']))
    t['tribe'] = t.genus.map(dl_tribe)
    # lifestyle: eusocial (corbiculate tribes, or EuPollTrait/BeeFunc eusocial), parasitic (brood parasites), other
    bf = t.species.map(S['bf_soc']).astype(str)
    t['sociality_eu'] = eusoc
    eus = (t.tribe.isin(EUSOCIAL_TRIBES) & ~t.psithyrus) | eusoc.eq('eusocial') | bf.str.contains('eusocial')
    par = t.psithyrus | t.tribe.isin(PARASITIC_TRIBES) | t.genus.isin(PARASITIC_GENERA) | eusoc.isin(['brood_parasite', 'obligate_inquiline'])
    t['lifestyle'] = np.where(eus, 'eusocial', np.where(par, 'brood parasite', 'solitary/other'))
    t['hemisphere'] = np.where(t.frac_north >= 0.9, 'N', np.where(t.frac_north <= 0.1, 'S', 'both'))
    return t

# =============================================================== assemblages
_ASM = {}
def _occ(km=110.0):
    if km not in _ASM:
        cube = pc.load_cube(GROUP)[['species', 'genus', 'gcol', 'grow']]
        lat = 90 - cube.grow.values / 2 - 0.25; lon = cube.gcol.values / 2 - 180 + 0.25
        cube['cell'] = pc.ea_cell(lat, lon, km)
        occ = cube[['cell', 'species', 'genus']].drop_duplicates(['cell', 'species'])
        occ['isb'] = (occ.genus == 'Bombus').astype(int)
        tot = occ.groupby('cell').agg(n_species=('species', 'size'), n_bombus_all=('isb', 'sum'))
        cc = pc.cell_climate(); cc['cell'] = pc.ea_cell(cc.lat.values, cc.lon.values, km)
        clim = cc.groupby('cell')[['bio1', 'bio4', 'bio5', 'bio12', 'bio15']].mean()
        _ASM[km] = (occ, tot, clim)
    return _ASM[km]

def assemblages(traits, cols, min_species=5, min_coverage=0.0, km=110.0):
    """Same aggregation as pmla_common.assemblages (unique species per cell; coverage = n_trait / all GBIF species),
    plus Bombus shares: share of all GBIF species (bshare_all) and of trait species (bshare_trait)."""
    occ, tot, clim = _occ(km)
    tr = traits[['species'] + list(cols)].dropna(subset=list(cols), how='all').groupby('species', as_index=False).mean(numeric_only=True)
    m = occ.merge(tr, on='species', how='inner')
    agg = m.groupby('cell').agg(n_trait=('species', 'size'), n_bombus_trait=('isb', 'sum'),
                                **{f'{c}_mean': (c, 'mean') for c in cols}, **{f'{c}_sd': (c, 'std') for c in cols})
    out = agg.join(tot).reset_index(); out['coverage'] = out.n_trait / out.n_species
    out = out[(out.n_trait >= min_species) & (out.coverage >= min_coverage)].copy()
    out['lat'], out['lon'] = pc.ea_centroid(out.cell.values, km); out['abslat'] = out.lat.abs()
    out['bshare_all'] = out.n_bombus_all / out.n_species; out['bshare_trait'] = out.n_bombus_trait / out.n_trait
    return out.merge(clim, left_on='cell', right_index=True, how='left')

def in_region(lon, lat, reg):
    a, b, c, d = REGIONS[reg]
    return (lon >= a) & (lon <= b) & (lat >= c) & (lat <= d)

# =============================================================== main
def main():
    os.makedirs(OUT, exist_ok=True); os.makedirs(DATA_OUT, exist_ok=True)
    fp_cache = '/mnt/user-data/outputs/results/bees/code/gbif_id_cache.json'
    if not os.path.exists(os.path.join(OUT, 'gbif_id_cache.json')) and os.path.exists(fp_cache):
        import shutil; shutil.copy(fp_cache, os.path.join(OUT, 'gbif_id_cache.json'))
    log('species ranges'); se = pc.species_env(GROUP)
    cube = pc.load_cube(GROUP)
    cube['lon'] = cube.gcol / 2 - 180 + 0.25
    se = se.merge(cube.drop_duplicates(['species', 'gcol', 'grow']).groupby('species').lon.median().rename('lon_median'), left_on='species', right_index=True, how='left')
    b5 = cube.drop_duplicates(['species', 'gcol', 'grow']).merge(pc.cell_climate()[['grow', 'gcol', 'bio5']], on=['grow', 'gcol'], how='left')
    se = se.merge(b5.groupby('species').bio5.mean().rename('bio5_mean'), left_on='species', right_index=True, how='left')   # range-mean max temp of warmest month
    accepted, s2a, dl_tribe = load_dl(P['dl']); match = Matcher(se.species.values, s2a)
    log(f'GBIF species {len(se)}; Discover Life accepted {len(accepted)}, synonyms used {len(s2a)}')
    cov_rows, conflicts = [], []
    S = load_sources(match, cov_rows, conflicts)
    T = build_species_table(S, se, dl_tribe)
    A = T[T.n_cells >= 3].copy()
    pd.DataFrame(conflicts).to_csv(os.path.join(OUT, 'ostwald2024_name_key_conflicts.csv'), index=False)
    log(f'Ostwald 2024 verbatim-vs-key conflicts: {len(conflicts)} names')

    # ---------------- tree
    tree = pc.read_tree(P['tree'])
    tips = []
    for lf in tree.leaf_node_iter():
        raw = lf.taxon.label; g, how = match(raw)
        tips.append(dict(tip=raw, clean=pc.clean_name(raw), gbif_species=g, how=how))
        if g: lf.taxon.label = g.replace(' ', '_')
    tips = pd.DataFrame(tips)
    tips['duplicate_of_earlier_tip'] = tips.gbif_species.notna() & tips.duplicated('gbif_species')
    tips.to_csv(os.path.join(DATA_OUT, 'tree_tip_matching.csv'), index=False)
    register_tree(tree)
    in_tree = _TREE_NAMES[id(tree)]
    lens = [l.distance_from_root() for l in tree.leaf_node_iter()]
    tree_info = dict(n_tips=len(tips), matched=int(tips.gbif_species.notna().sum()), exact=int((tips.how == 'exact').sum()),
                     synonym=int((tips.how == 'synonym').sum()), duplicates=int(tips.duplicate_of_earlier_tip.sum()),
                     root_to_tip_min=float(np.min(lens)), root_to_tip_max=float(np.max(lens)))
    A['in_tree'] = A.species.isin(in_tree)
    log('tree', tree_info)
    # pruned tree for the package (tips = analysed species with any trait)
    try:
        keep_names = set(A.dropna(subset=['log_itd', 'log_blen', 'struc', 'lightness', 'log_hairiness_eu'], how='all').species) & in_tree
        t2 = pc.read_tree(P['tree'])
        seen = set(); drop = []
        for lf in t2.leaf_node_iter():
            g, _ = match(lf.taxon.label)
            if g and g in keep_names and g not in seen: lf.taxon.label = g.replace(' ', '_'); seen.add(g)
            else: drop.append(lf.taxon)
        t2.prune_taxa(drop); t2.write(path=os.path.join(DATA_OUT, 'bee_tree_pruned_analysed_species.nwk'), schema='newick', suppress_rooting=True)
        tree_info['pruned_tips'] = len(seen)
    except Exception as e:
        log('pruned tree failed', e)

    # ---------------- coverage + source agreement
    cov = pd.DataFrame(cov_rows)
    an = []
    for c, lab in [('log_itd', 'ITD (composite)'), ('log_itd_female', 'ITD (females only)'), ('log_blen', 'body length (composite)'),
                   ('lightness', 'lightness'), ('pilosity', 'pilosity'), ('log_hairiness_eu', 'hairiness index (Europe)'), ('struc', 'structural colour')]:
        a = A.dropna(subset=[c])
        an.append(dict(trait=lab, n_species_with_trait=int(T[c].notna().sum()), n_analysed_ncells3=len(a), n_in_tree=int(a.in_tree.sum()),
                       n_tropical=int((a.abslat_median < 23.44).sum()), n_southern=int((a.frac_north <= 0.1).sum()),
                       abslat_min=a.abslat_median.min(), abslat_max=a.abslat_median.max(), abslat_median=a.abslat_median.median(),
                       n_genera=a.genus.nunique(), n_families=a.family.nunique()))
    an = pd.DataFrame(an)
    cov.to_csv(os.path.join(OUT, 'name_matching_by_source.csv'), index=False); an.to_csv(os.path.join(OUT, 'analysed_species_by_trait.csv'), index=False)
    ag = []
    for a_, b_ in [('itd_eu', 'log_itd_ost'), ('itd_eu', 'itd_ken'), ('log_itd_ost', 'itd_ken'), ('itd_eu', 'itd_bf'), ('bl_hp', 'bl_ken'), ('bl_hp', 'log_bl_ost'),
                   ('log_itd_ost', 'log_itd_ost_firstpass')]:
        d = T.dropna(subset=[a_, b_])
        la = d[a_] if a_.startswith('log') else np.log10(d[a_]); lb = d[b_] if b_.startswith('log') else np.log10(d[b_])
        if len(d) >= 5:
            ag.append(dict(source_a=a_, source_b=b_, n=len(d), r_log10=np.corrcoef(la, lb)[0, 1], mean_diff_log10=(la - lb).mean(),
                           n_diff_gt_0p1=int(((la - lb).abs() > 0.1).sum())))
    d = A.dropna(subset=['log_itd', 'log_blen']); ag.append(dict(source_a='log_itd', source_b='log_blen', n=len(d), r_log10=np.corrcoef(d.log_itd, d.log_blen)[0, 1]))
    pd.DataFrame(ag).to_csv(os.path.join(OUT, 'trait_source_agreement.csv'), index=False)
    json.dump(tree_info, open(os.path.join(OUT, 'tree_info.json'), 'w'), indent=1)

    # =========================================================== A. species level
    log('A. species level')
    AIC = []
    CONT = ['log_itd', 'log_blen', 'lightness', 'pilosity', 'log_hairiness_eu']
    def species_block(d0, y, subset, preds=('abslat_median', 'bio1_mean'), pgls=True, lmm=True, fam=True, aic=False, quad=False, note=''):
        d = d0.dropna(subset=[y, 'abslat_median', 'bio1_mean', 'bio12_mean', 'genus', 'family']).copy()
        if len(d) < 15: return
        dt = d[d.species.isin(in_tree)]
        for x in preds:
            m = fit_ols(d, y, [x])
            add_row('species', y, subset, 'OLS', x, x, int(m.nobs), m.params[x], m.bse[x], m.pvalues[x], df=m.df_resid, x=d[x], yv=d[y], r2=m.rsquared, note=note)
            if lmm and d.genus.nunique() >= 5:
                mm, meth, nt = fit_lmm(d, y, [x], fam=fam)
                if mm is not None:
                    add_row('species', y, subset, 'LMM', x, x, int(mm.nobs), mm.params[x], mm.bse[x], mm.pvalues[x], x=d[x], yv=d[y],
                            genus_var=float(mm.cov_re.iloc[0, 0]), resid_var=float(mm.scale), n_genera=d.genus.nunique(), optimizer=meth, note=(note + ' ' + nt).strip())
            if pgls and len(dt) >= 15:
                r = pgls_fast(dt, y, [x], tree); row = r['table'].set_index('term').loc[x]
                add_row('species', y, subset, 'PGLS', x, x, r['n'], row.estimate, row.se, row.p, df=r['df'], x=dt[x], yv=dt[y],
                        pagel_lambda=r['lambda'], LR_lambda_vs_0=r['LR_lambda_vs_0'], note=note)
        if quad:
            c0 = d.abslat_median.mean(); d['abslat_c'] = d.abslat_median - c0; d['abslat_c2'] = d.abslat_c ** 2; dt = d[d.species.isin(in_tree)]
            m1 = fit_ols(d, y, ['abslat_c']); m2 = fit_ols(d, y, ['abslat_c', 'abslat_c2'])
            vx = c0 - m2.params['abslat_c'] / (2 * m2.params['abslat_c2'])
            add_row('species', y, subset, 'OLS quadratic', 'abslat_median', 'abslat_c2', int(m2.nobs), m2.params['abslat_c2'], m2.bse['abslat_c2'], m2.pvalues['abslat_c2'],
                    df=m2.df_resid, dAIC_vs_linear=m2.aic - m1.aic, vertex_deg=vx, centre=c0)
            if lmm:
                l1, _, _ = fit_lmm(d, y, ['abslat_c'], reml=False); l2, meth, nt = fit_lmm(d, y, ['abslat_c', 'abslat_c2'], reml=False)
                if l2 is not None:
                    vx = c0 - l2.params['abslat_c'] / (2 * l2.params['abslat_c2'])
                    add_row('species', y, subset, 'LMM quadratic (ML)', 'abslat_median', 'abslat_c2', int(l2.nobs), l2.params['abslat_c2'], l2.bse['abslat_c2'], l2.pvalues['abslat_c2'],
                            dAIC_vs_linear=(l2.aic - l1.aic) if l1 is not None else np.nan, vertex_deg=vx, centre=c0, optimizer=meth, note=nt)
            if pgls and len(dt) >= 15:
                r1 = pgls_fast(dt, y, ['abslat_c'], tree); r2 = pgls_fast(dt, y, ['abslat_c', 'abslat_c2'], tree); tb = r2['table'].set_index('term')
                vx = c0 - tb.loc['abslat_c', 'estimate'] / (2 * tb.loc['abslat_c2', 'estimate'])
                add_row('species', y, subset, 'PGLS quadratic', 'abslat_median', 'abslat_c2', r2['n'], tb.loc['abslat_c2', 'estimate'], tb.loc['abslat_c2', 'se'], tb.loc['abslat_c2', 'p'],
                        df=r2['df'], dAIC_vs_linear=(-2 * r2['logLik'] + 2 * r2['k']) - (-2 * r1['logLik'] + 2 * r1['k']), vertex_deg=vx, centre=c0, pagel_lambda=r2['lambda'])
        if aic:
            forms = {'abslat': ['abslat_median'], 'bio1': ['bio1_mean'], 'bio1+bio12': ['bio1_mean', 'bio12_mean'], 'abslat+bio12': ['abslat_median', 'bio12_mean'],
                     'abslat+bio1': ['abslat_median', 'bio1_mean']}
            if y in ('lightness', 'pilosity'): forms.update({'bio5': ['bio5_mean'], 'bio5+bio12': ['bio5_mean', 'bio12_mean']})
            d = d.dropna(subset=['bio5_mean']); dt = d[d.species.isin(in_tree)]
            row = dict(trait=y, subset=subset, n=len(d))
            for kf, xs in forms.items():
                row[f'OLS_AIC_{kf}'] = fit_ols(d, y, xs).aic
                mm, meth, nt = fit_lmm(d, y, xs, reml=False)
                row[f'LMM_ML_AIC_{kf}'] = mm.aic if mm is not None and mm.converged else np.nan
            row['n_tree'] = len(dt)
            if len(dt) >= 15:
                for kf, xs in forms.items():
                    r = pgls_fast(dt, y, xs, tree); row[f'PGLS_AIC_{kf}'] = -2 * r['logLik'] + 2 * r['k']
            AIC.append(row)

    for y in CONT:
        species_block(A, y, 'all', aic=True, quad=True, preds=('abslat_median', 'bio1_mean', 'bio5_mean') if y in ('lightness', 'pilosity') else ('abslat_median', 'bio1_mean'))
        species_block(A[A.hemisphere == 'N'], y, 'N hemisphere (>=90% cells N)')
        species_block(A[A.hemisphere == 'S'], y, 'S hemisphere (>=90% cells S)')
        species_block(A[~A.introduced], y, 'no introduced')
        species_block(A[A.n_cells >= 10], y, '>=10 cells')
        log('  species', y)
    # ITD sensitivities
    for sub, d in [('females only (no BeeFunc/unknown sex)', A.assign(log_itd=A.log_itd_female)),
                   ('no eusocial species', A[A.lifestyle != 'eusocial']), ('no Bombus', A[A.genus != 'Bombus']),
                   ('no brood parasites', A[A.lifestyle != 'brood parasite']),
                   ('EuPollTrait/BeeFunc value only', A.assign(log_itd=np.log10(A.itd_euro))),
                   ('Ostwald 2024 value only', A.assign(log_itd=A.log_itd_ost)),
                   ('first-pass Ostwald name assignment', A.assign(log_itd=A.log_itd_firstpass_names)),
                   ('>=2 ITD sources', A[A.n_itd_sources >= 2]),
                   ('lat_mid instead of median', A.assign(abslat_median=A.lat_mid.abs())),
                   ('W Palaearctic species', A[in_region(A.lon_median, A.lat_median, 'W Palaearctic')]),
                   ('Nearctic species', A[in_region(A.lon_median, A.lat_median, 'Nearctic')]),
                   ('Neotropical species', A[in_region(A.lon_median, A.lat_median, 'Neotropics')]),
                   ('Nearctic species, no Bombus', A[in_region(A.lon_median, A.lat_median, 'Nearctic') & (A.genus != 'Bombus')]),
                   ('Nearctic species, females only', A[in_region(A.lon_median, A.lat_median, 'Nearctic')].assign(log_itd=lambda z: z.log_itd_female)),
                   ('W Palaearctic species, females only', A[in_region(A.lon_median, A.lat_median, 'W Palaearctic')].assign(log_itd=lambda z: z.log_itd_female))]:
        species_block(d, 'log_itd', sub, aic=sub.startswith('females'))
    species_block(A.assign(log_hairiness_eu=A.log_hairiness_eu.where(A.genus != 'Bombus')), 'log_hairiness_eu', 'no Bombus')
    log('  sensitivities done')
    # hemisphere interaction (species level, OLS + LMM + PGLS) for ITD
    d = A.dropna(subset=['log_itd', 'abslat_median', 'genus', 'family'])
    d = d[d.hemisphere.isin(['N', 'S'])].assign(south=lambda z: (z.hemisphere == 'S').astype(float))
    d['abslat_x_south'] = d.abslat_median * d.south
    m = fit_ols(d, 'log_itd', ['abslat_median', 'south', 'abslat_x_south'])
    add_row('species', 'log_itd', 'hemisphere interaction', 'OLS', 'abslat x south', 'abslat_x_south', int(m.nobs), m.params['abslat_x_south'], m.bse['abslat_x_south'], m.pvalues['abslat_x_south'], df=m.df_resid)
    mm, meth, nt = fit_lmm(d, 'log_itd', ['abslat_median', 'south', 'abslat_x_south'])
    if mm is not None: add_row('species', 'log_itd', 'hemisphere interaction', 'LMM', 'abslat x south', 'abslat_x_south', int(mm.nobs), mm.params['abslat_x_south'], mm.bse['abslat_x_south'], mm.pvalues['abslat_x_south'], optimizer=meth, note=nt)
    r = pgls_fast(d[d.species.isin(in_tree)], 'log_itd', ['abslat_median', 'south', 'abslat_x_south'], tree); tb = r['table'].set_index('term')
    add_row('species', 'log_itd', 'hemisphere interaction', 'PGLS', 'abslat x south', 'abslat_x_south', r['n'], tb.loc['abslat_x_south', 'estimate'], tb.loc['abslat_x_south', 'se'], tb.loc['abslat_x_south', 'p'], df=r['df'], pagel_lambda=r['lambda'])

    # ---------------- family and genus level (species models)
    log('family / genus species models')
    for f in FAMILIES:
        for y in ['log_itd', 'log_blen']:
            d = A[A.family == f]
            if d[y].notna().sum() >= 20: species_block(d, y, f'family: {f}', fam=False)
    gcount = A.dropna(subset=['log_itd']).groupby('genus').size()
    GEN = sorted(gcount[gcount >= 30].index.tolist(), key=lambda g: -gcount[g])
    for g in GEN:
        d = A[A.genus == g]
        species_block(d, 'log_itd', f'genus: {g}', lmm=False, fam=False)
    B = A[A.genus == 'Bombus']
    species_block(B[~B.psithyrus], 'log_itd', 'genus: Bombus social (no Psithyrus)', lmm=False, fam=False)
    species_block(B[~B.introduced], 'log_itd', 'genus: Bombus no introduced', lmm=False, fam=False)
    species_block(B, 'log_blen', 'genus: Bombus', lmm=False, fam=False)
    # lifestyle classes (global, tribe/genus-based) and European sociality (EuPollTrait)
    for cl in ['eusocial', 'solitary/other', 'brood parasite']:
        species_block(A[A.lifestyle == cl], 'log_itd', f'lifestyle: {cl}')
    E = A[A.sociality_eu.notna()].copy()
    E['soc3'] = np.where(E.sociality_eu.isin(['eusocial']), 'eusocial', np.where(E.sociality_eu.isin(['brood_parasite', 'obligate_inquiline', 'facultative_inquiline']), 'parasitic', 'solitary'))
    for cl in ['eusocial', 'solitary', 'parasitic']:
        species_block(E[E.soc3 == cl], 'log_itd', f'Europe sociality (EuPollTrait): {cl}')
    d = A.dropna(subset=['log_itd', 'abslat_median', 'genus', 'family']).assign(eus=lambda z: (z.lifestyle == 'eusocial').astype(float))
    d['abslat_x_eus'] = d.abslat_median * d.eus
    m = fit_ols(d, 'log_itd', ['abslat_median', 'eus', 'abslat_x_eus'])
    add_row('species', 'log_itd', 'lifestyle interaction (eusocial vs rest)', 'OLS', 'abslat x eusocial', 'abslat_x_eus', int(m.nobs), m.params['abslat_x_eus'], m.bse['abslat_x_eus'], m.pvalues['abslat_x_eus'], df=m.df_resid)
    r = pgls_fast(d[d.species.isin(in_tree)], 'log_itd', ['abslat_median', 'eus', 'abslat_x_eus'], tree); tb = r['table'].set_index('term')
    add_row('species', 'log_itd', 'lifestyle interaction (eusocial vs rest)', 'PGLS', 'abslat x eusocial', 'abslat_x_eus', r['n'], tb.loc['abslat_x_eus', 'estimate'], tb.loc['abslat_x_eus', 'se'], tb.loc['abslat_x_eus', 'p'], df=r['df'], pagel_lambda=r['lambda'])

    # ---------------- structural colour (binary)
    log('structural colour species level')
    def struc_block(d, yv, x, subset, pgls=True, gee_family=False):
        d = d.dropna(subset=[yv, x]).copy()
        if len(d) < 30 or d[yv].nunique() < 2: return
        g = smf.glm(f'{yv} ~ {x}', d, family=sm.families.Binomial()).fit()
        add_row('species', 'struc', subset, 'GLM logit', x, x, int(g.nobs), g.params[x], g.bse[x], g.pvalues[x], x=d[x], yv=None,
                prevalence=d[yv].mean(), aic=g.aic, note='log-odds; std_effect = log-odds per SD of predictor')
        ROWS[-1]['std_effect'] = g.params[x] * np.nanstd(d[x], ddof=1)
        if d.genus.nunique() >= 10:
            gee = smf.gee(f'{yv} ~ {x}', groups='genus', data=d, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
            add_row('species', 'struc', subset, 'GEE logit (genus clusters, exchangeable)', x, x, int(gee.nobs), gee.params[x], gee.bse[x], gee.pvalues[x],
                    prevalence=d[yv].mean(), n_clusters=d.genus.nunique())
            ROWS[-1]['std_effect'] = gee.params[x] * np.nanstd(d[x], ddof=1)
        if gee_family and d.family.nunique() >= 5:
            gee = smf.gee(f'{yv} ~ {x}', groups='family', data=d, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
            add_row('species', 'struc', subset, 'GEE logit (family clusters)', x, x, int(gee.nobs), gee.params[x], gee.bse[x], gee.pvalues[x], n_clusters=d.family.nunique())
        dt = d[d.species.isin(in_tree)] if 'species' in d else d.iloc[0:0]
        if pgls and len(dt) > 30:
            r = pgls_fast(dt, yv, [x], tree); row = r['table'].set_index('term').loc[x]
            add_row('species', 'struc', subset, 'PGLS linear probability', x, x, r['n'], row.estimate, row.se, row.p, df=r['df'],
                    pagel_lambda=r['lambda'], prevalence=dt[yv].mean())
    h = S['hp_all'].copy(); h['abslat_hp'] = h.median_latitude.abs()
    h['genus'] = h.hp_name.astype(str).str.split('[ _]').str[0]
    struc_block(h, 'struc_present', 'abslat_hp', 'HP2026 own latitudes (all 2,001 names)', pgls=False, gee_family=False)
    struc_block(h, 'struc_present', 'mean_annualt_data', 'HP2026 own climate (all names)', pgls=False)
    As = A.copy()
    struc_block(As, 'struc', 'abslat_median', 'all', gee_family=True)
    struc_block(As, 'struc', 'bio1_mean', 'all')
    struc_block(As, 'struc_female', 'abslat_median', 'female structural colour only')
    struc_block(As[~As.introduced], 'struc', 'abslat_median', 'no introduced')
    struc_block(As[As.genus != 'Bombus'], 'struc', 'abslat_median', 'no Bombus')
    struc_block(As[As.hemisphere == 'N'], 'struc', 'abslat_median', 'N hemisphere (>=90% cells N)')
    struc_block(As[As.hemisphere == 'S'], 'struc', 'abslat_median', 'S hemisphere (>=90% cells S)')
    for f in FAMILIES:
        struc_block(As[As.family == f], 'struc', 'abslat_median', f'family: {f}')
    # AIC latitude vs temperature for structural colour (GLM, identical rows) + quadratic
    d = As.dropna(subset=['struc', 'abslat_median', 'bio1_mean', 'bio12_mean'])
    row = dict(trait='struc', subset='all', n=len(d))
    for kf, xs in {'abslat': ['abslat_median'], 'bio1': ['bio1_mean'], 'bio1+bio12': ['bio1_mean', 'bio12_mean'], 'abslat+bio12': ['abslat_median', 'bio12_mean'],
                   'abslat+bio1': ['abslat_median', 'bio1_mean']}.items():
        row[f'GLM_AIC_{kf}'] = smf.glm(f'struc ~ ' + ' + '.join(xs), d, family=sm.families.Binomial()).fit().aic
    AIC.append(row)
    d = d.assign(abslat_c=d.abslat_median - d.abslat_median.mean()); d['abslat_c2'] = d.abslat_c ** 2
    g1 = smf.glm('struc ~ abslat_c', d, family=sm.families.Binomial()).fit(); g2 = smf.glm('struc ~ abslat_c + abslat_c2', d, family=sm.families.Binomial()).fit()
    add_row('species', 'struc', 'all', 'GLM logit quadratic', 'abslat_median', 'abslat_c2', int(g2.nobs), g2.params['abslat_c2'], g2.bse['abslat_c2'], g2.pvalues['abslat_c2'], dAIC_vs_linear=g2.aic - g1.aic)

    # ---------------- specimen level (Ostwald 2025)
    log('specimen level lightness / pilosity')
    sp = S['ost25_spec'].copy()
    swap = (sp.Country == 'Brazil') & (sp.Latitude < -35) & (sp.Longitude > -35)   # lat/lon swapped (Micronychapis duckei, Sao Paulo)
    sp.loc[swap, ['Latitude', 'Longitude']] = sp.loc[swap, ['Longitude', 'Latitude']].values
    sp['coord_note'] = np.where(swap, 'lat/lon swapped in source, corrected', '')
    sp = sp[sp.Latitude.between(-90, 90) & sp.Longitude.between(-180, 180)].copy()
    cc = pc.cell_climate()[['grow', 'gcol', 'bio1', 'bio5', 'bio12']]
    sp['grow'] = np.floor((90 - sp.Latitude) / 0.5).astype(int); sp['gcol'] = np.floor((sp.Longitude + 180) / 0.5).astype(int)
    sp = sp.merge(cc, on=['grow', 'gcol'], how='left')
    sp['abslat'] = sp.Latitude.abs(); sp['genus'] = sp.Genus; sp['family'] = sp.Family
    spx = sp.dropna(subset=['bio1', 'bio5', 'bio12'])       # identical rows for latitude and climate models
    n_spec_info = dict(n_records=len(S['ost25_spec']), n_valid_coords=len(sp), n_on_land_with_climate=len(spx), n_swapped_fixed=int(swap.sum()),
                       lat_min=float(spx.Latitude.min()), lat_max=float(spx.Latitude.max()), n_species=int(spx.species.nunique()), n_genera=int(spx.genus.nunique()))
    json.dump(n_spec_info, open(os.path.join(OUT, 'specimen_info.json'), 'w'), indent=1)
    SPA = []
    for y in ['lightness', 'pilosity']:
        for x in ['abslat', 'bio1', 'bio5', 'bio12']:
            m = fit_ols(spx, y, [x])
            add_row('specimen', y, 'Ostwald 2025 females', 'OLS', x, x, int(m.nobs), m.params[x], m.bse[x], m.pvalues[x], df=m.df_resid, x=spx[x], yv=spx[y], r2=m.rsquared)
            m = fit_ols(spx, y, [x, 'C(family)'])
            add_row('specimen', y, 'Ostwald 2025 females', 'OLS + family', x, x, int(m.nobs), m.params[x], m.bse[x], m.pvalues[x], df=m.df_resid, x=spx[x], yv=spx[y])
            mm, meth, nt = fit_lmm(spx, y, [x])
            if mm is not None:
                add_row('specimen', y, 'Ostwald 2025 females', 'LMM', x, x, int(mm.nobs), mm.params[x], mm.bse[x], mm.pvalues[x], x=spx[x], yv=spx[y],
                        genus_var=float(mm.cov_re.iloc[0, 0]), resid_var=float(mm.scale), optimizer=meth, note=nt, n_genera=spx.genus.nunique())
        # hemisphere-specific latitude slopes (specimens)
        for hem, dd in [('N', spx[spx.Latitude > 0]), ('S', spx[spx.Latitude < 0])]:
            m = fit_ols(dd, y, ['abslat']); add_row('specimen', y, f'{hem} hemisphere specimens', 'OLS', 'abslat', 'abslat', int(m.nobs), m.params['abslat'], m.bse['abslat'], m.pvalues['abslat'], df=m.df_resid)
            mm, meth, nt = fit_lmm(dd, y, ['abslat'])
            if mm is not None: add_row('specimen', y, f'{hem} hemisphere specimens', 'LMM', 'abslat', 'abslat', int(mm.nobs), mm.params['abslat'], mm.bse['abslat'], mm.pvalues['abslat'], optimizer=meth, note=nt)
        row = dict(trait=y, subset='specimens', n=len(spx))
        for kf, xs in {'abslat': ['abslat'], 'bio1': ['bio1'], 'bio5': ['bio5'], 'bio5+bio12': ['bio5', 'bio12'], 'abslat+bio12': ['abslat', 'bio12'], 'bio1+bio12': ['bio1', 'bio12']}.items():
            row[f'OLS_AIC_{kf}'] = fit_ols(spx, y, xs).aic
            mm, meth, nt = fit_lmm(spx, y, xs, reml=False)
            row[f'LMM_ML_AIC_{kf}'] = mm.aic if mm is not None and mm.converged else np.nan
        AIC.append(row)
    sp.to_csv(os.path.join(DATA_OUT, 'ostwald2025_specimens_with_climate.csv'), index=False)

    # =========================================================== B. assemblage level
    log('B. assemblages')
    ACOV, CELLS = [], {}
    def asm_block(tr, y, subset, min_species=5, min_cov=0.0, region=None, forms=None, keep=False, cells=None, aic=False, quad=False, extra=None):
        ce = assemblages(tr[['species', y]].dropna(), [y], min_species=min_species, min_coverage=min_cov)
        ce = ce.dropna(subset=[f'{y}_mean', 'bio1', 'bio12', 'bio4'])
        if y == 'log_hairiness_eu': ce = ce[in_region(ce.lon, ce.lat, 'W Palaearctic')]
        if region: ce = ce[region(ce)]
        if cells is not None: ce = ce[ce.cell.isin(cells)]
        ACOV.append(dict(trait=y, subset=subset, n_cells=len(ce), median_n_trait=ce.n_trait.median() if len(ce) else np.nan,
                         median_n_species=ce.n_species.median() if len(ce) else np.nan, median_coverage=ce.coverage.median() if len(ce) else np.nan,
                         q25_coverage=ce.coverage.quantile(0.25) if len(ce) else np.nan, abslat_min=ce.abslat.min() if len(ce) else np.nan,
                         abslat_max=ce.abslat.max() if len(ce) else np.nan, frac_south=(ce.lat < 0).mean() if len(ce) else np.nan,
                         frac_WPal=in_region(ce.lon, ce.lat, 'W Palaearctic').mean() if len(ce) else np.nan,
                         frac_Nearctic=in_region(ce.lon, ce.lat, 'Nearctic').mean() if len(ce) else np.nan))
        if len(ce) < 30 or ce[f'{y}_mean'].std() == 0: return ce
        if keep: CELLS[(y, subset)] = ce
        yy = f'{y}_mean'
        for xs in (forms or [['abslat'], ['bio1']]):
            r = sar_error_lu(ce, yy, xs)
            for _, rw in r['table'].iterrows():
                if rw.term == 'CONSTANT': continue
                add_row('assemblage', y, subset, 'SAR error', ' + '.join(xs), rw.term, r['n'], rw.estimate, rw.se, rw.p,
                        x=ce[rw.term] if rw.term in ce else None, yv=ce[yy], sar_lambda=r['lambda'], moran_I_ols=r['moran_I_ols_resid'],
                        moran_p_ols=r['moran_p'], moran_I_sar=r['moran_I_sar_resid'], pseudo_r2=r['pseudo_r2'], aic=r['aic'], ols_r2=r['ols_r2'],
                        median_coverage=ce.coverage.median())
        if quad:
            c0 = ce.abslat.mean(); ce2 = ce.assign(abslat_c=ce.abslat - c0); ce2['abslat_c2'] = ce2.abslat_c ** 2
            r1 = sar_error_lu(ce2, yy, ['abslat_c']); r2 = sar_error_lu(ce2, yy, ['abslat_c', 'abslat_c2']); tb = r2['table'].set_index('term')
            add_row('assemblage', y, subset, 'SAR error quadratic', 'abslat + abslat^2', 'abslat_c2', r2['n'], tb.loc['abslat_c2', 'estimate'], tb.loc['abslat_c2', 'se'], tb.loc['abslat_c2', 'p'],
                    dAIC_vs_linear=r2['aic'] - r1['aic'], vertex_deg=c0 - tb.loc['abslat_c', 'estimate'] / (2 * tb.loc['abslat_c2', 'estimate']), centre=c0, sar_lambda=r2['lambda'])
        if aic:
            row = dict(trait=y, subset=subset, n=len(ce))
            for kf, xs in {'abslat': ['abslat'], 'bio1': ['bio1'], 'bio1+bio12': ['bio1', 'bio12'], 'abslat+bio12': ['abslat', 'bio12'], 'abslat+bio1': ['abslat', 'bio1']}.items():
                row[f'SAR_AIC_{kf}'] = sar_error_lu(ce, yy, xs)['aic']; row[f'OLS_AIC_{kf}'] = fit_ols(ce, yy, xs).aic
            AIC.append(row)
        return ce
    ATR = ['log_itd', 'log_blen', 'struc', 'lightness', 'pilosity', 'log_hairiness_eu']
    main_cells = {}
    for y in ATR:
        ce = asm_block(T, y, 'main (>=5 spp)', keep=True, aic=True, quad=True, forms=[['abslat'], ['bio1'], ['bio1', 'bio12'], ['abslat', 'bio12']])
        main_cells[y] = set(ce.cell)
        asm_block(T, y, '>=10 spp', min_species=10)
        asm_block(T, y, 'coverage >=0.3', min_cov=0.3)
        asm_block(T, y, 'coverage >=0.5', min_cov=0.5)
        asm_block(T[~T.introduced], y, 'no introduced')
        asm_block(T[T.genus != 'Bombus'], y, 'no Bombus (own cells)', keep=True)
        asm_block(T, y, 'N hemisphere cells', region=lambda c: c.lat > 0)
        asm_block(T, y, 'S hemisphere cells', region=lambda c: c.lat < 0)
        if y != 'log_hairiness_eu':
            for reg in ['W Palaearctic', 'Nearctic', 'Neotropics', 'Tropics (|lat|<23.4)']:
                asm_block(T, y, f'region: {reg}', region=lambda c, reg=reg: in_region(c.lon, c.lat, reg))
        log('  assemblage', y)
    asm_block(T.assign(log_itd=T.log_itd_female), 'log_itd', 'females-only ITD')
    asm_block(T.assign(log_itd=T.log_itd_firstpass_names), 'log_itd', 'first-pass Ostwald names')
    asm_block(T[T.lifestyle != 'eusocial'], 'log_itd', 'no eusocial species')
    # ---- Bombus mechanism: identical cells (>=5 non-Bombus species with ITD)
    log('Bombus mechanism')
    nb = assemblages(T[T.genus != 'Bombus'][['species', 'log_itd']].dropna(), ['log_itd'], min_species=5).dropna(subset=['log_itd_mean', 'bio1'])
    allc = assemblages(T[['species', 'log_itd']].dropna(), ['log_itd'], min_species=5).dropna(subset=['log_itd_mean', 'bio1'])
    same = allc.merge(nb[['cell', 'log_itd_mean', 'n_trait']].rename(columns={'log_itd_mean': 'itd_nobombus', 'n_trait': 'n_trait_nobombus'}), on='cell')
    bo = assemblages(T[T.genus == 'Bombus'][['species', 'log_itd']].dropna(), ['log_itd'], min_species=1)[['cell', 'log_itd_mean', 'n_trait']].rename(columns={'log_itd_mean': 'itd_bombus', 'n_trait': 'n_bombus_itd'})
    same = same.merge(bo, on='cell', how='left')
    same['diff_all_minus_nob'] = same.log_itd_mean - same.itd_nobombus
    same.to_csv(os.path.join(DATA_OUT, 'assemblage_cells_ITD_bombus_decomposition.csv'), index=False)
    CELLS[('log_itd', 'same cells')] = same
    for lab, yy, xs in [('same cells: all bees', 'log_itd_mean', ['abslat']), ('same cells: without Bombus', 'itd_nobombus', ['abslat']),
                        ('same cells: all bees', 'log_itd_mean', ['bio1']), ('same cells: without Bombus', 'itd_nobombus', ['bio1']),
                        ('same cells: all bees', 'log_itd_mean', ['bshare_all']), ('same cells: all bees', 'log_itd_mean', ['abslat', 'bshare_all']),
                        ('same cells: all bees', 'log_itd_mean', ['abslat', 'bshare_trait']),
                        ('same cells: Bombus share (all GBIF spp)', 'bshare_all', ['abslat']), ('same cells: Bombus share (ITD spp)', 'bshare_trait', ['abslat']),
                        ('same cells: all minus no-Bombus mean', 'diff_all_minus_nob', ['abslat'])]:
        r = sar_error_lu(same, yy, xs)
        for _, rw in r['table'].iterrows():
            if rw.term == 'CONSTANT': continue
            add_row('assemblage', 'log_itd' if 'share' not in lab else 'bombus_share', lab, 'SAR error', ' + '.join(xs), rw.term, r['n'], rw.estimate, rw.se, rw.p,
                    x=same[rw.term], yv=same[yy], sar_lambda=r['lambda'], moran_I_ols=r['moran_I_ols_resid'], moran_I_sar=r['moran_I_sar_resid'], pseudo_r2=r['pseudo_r2'], aic=r['aic'])
    same['abslat_x_bshare'] = same.abslat * same.bshare_all
    r = sar_error_lu(same, 'log_itd_mean', ['abslat', 'bshare_all', 'abslat_x_bshare'])
    for _, rw in r['table'].iterrows():
        if rw.term != 'CONSTANT':
            add_row('assemblage', 'log_itd', 'same cells: all bees (interaction)', 'SAR error', 'abslat * bshare_all', rw.term, r['n'], rw.estimate, rw.se, rw.p,
                    sar_lambda=r['lambda'], moran_I_ols=r['moran_I_ols_resid'], pseudo_r2=r['pseudo_r2'], aic=r['aic'])
    # Bombus-only assemblages (>=5 and >=3 Bombus species with ITD)
    for ms in (5, 3):
        asm_block(T[T.genus == 'Bombus'], 'log_itd', f'Bombus only (>={ms} spp)', min_species=ms, keep=(ms == 5), forms=[['abslat'], ['bio1'], ['bio1', 'bio12']])
    # family and genus assemblages (ITD); structural colour by family
    log('family / genus assemblages')
    for f in FAMILIES:
        asm_block(T[T.family == f], 'log_itd', f'family: {f}')
        asm_block(T[T.family == f], 'struc', f'family: {f}')
    for g in GEN:
        asm_block(T[T.genus == g], 'log_itd', f'genus: {g}')
    for cl in ['eusocial', 'solitary/other', 'brood parasite']:
        asm_block(T[T.lifestyle == cl], 'log_itd', f'lifestyle: {cl}')
    # hairiness (Europe) with/without Bombus on identical cells
    hb = assemblages(T[T.genus != 'Bombus'][['species', 'log_hairiness_eu']].dropna(), ['log_hairiness_eu'], min_species=5).dropna(subset=['bio1'])
    hb = hb[in_region(hb.lon, hb.lat, 'W Palaearctic')]
    asm_block(T, 'log_hairiness_eu', 'same cells as no-Bombus', cells=set(hb.cell))
    asm_block(T[T.genus != 'Bombus'], 'log_hairiness_eu', 'no Bombus (same cells)', cells=set(hb.cell))
    ha = assemblages(T[['species', 'log_hairiness_eu']].dropna(), ['log_hairiness_eu'], min_species=5).dropna(subset=['bio1'])
    ha = ha[ha.cell.isin(hb.cell)]
    r = sar_error_lu(ha, 'log_hairiness_eu_mean', ['abslat', 'bshare_all'])
    for _, rw in r['table'].iterrows():
        if rw.term != 'CONSTANT':
            add_row('assemblage', 'log_hairiness_eu', 'Europe: all bees + Bombus share', 'SAR error', 'abslat + bshare_all', rw.term, r['n'], rw.estimate, rw.se, rw.p, sar_lambda=r['lambda'], aic=r['aic'])
    # structural colour without Bombus on identical cells
    sb = assemblages(T[T.genus != 'Bombus'][['species', 'struc']].dropna(), ['struc'], min_species=5).dropna(subset=['bio1'])
    asm_block(T, 'struc', 'same cells as no-Bombus', cells=set(sb.cell))
    asm_block(T[T.genus != 'Bombus'], 'struc', 'no Bombus (same cells)', cells=set(sb.cell))

    # ---------------- save
    R = pd.DataFrame(ROWS)
    R.to_csv(os.path.join(OUT, 'all_models.csv'), index=False)
    pd.DataFrame(AIC).to_csv(os.path.join(OUT, 'aic_latitude_vs_climate.csv'), index=False)
    pd.DataFrame(ACOV).to_csv(os.path.join(OUT, 'assemblage_coverage.csv'), index=False)
    for (y, sub), ce in CELLS.items():
        tag = re.sub(r'[^A-Za-z0-9]+', '_', f'{y}_{sub}').strip('_')
        ce.to_csv(os.path.join(DATA_OUT, f'assemblage_cells_{tag}.csv'), index=False)
    # species tables for the package
    keepc = ['species', 'family', 'genus', 'tribe', 'n_cells', 'n_records', 'abslat_median', 'lat_median', 'lat_mid', 'lat_q05', 'lat_q95', 'frac_north',
             'hemisphere', 'lon_median', 'bio1_mean', 'bio4_mean', 'bio5_mean', 'bio12_mean', 'bio15_mean', 'itd_eu', 'itd_bf', 'log_itd_ost', 'n_studies_ost', 'ost_sex_classes',
             'itd_ken', 'itd_sources', 'n_itd_sources', 'log_itd', 'log_itd_female', 'bl_hp', 'bl_ken', 'log_bl_ost', 'log_blen', 'hairiness_eu', 'log_hairiness_eu',
             'struc', 'struc_female', 'lightness', 'pilosity', 'lifestyle', 'sociality_eu', 'psithyrus', 'introduced', 'in_tree']
    A['in_tree'] = A.species.isin(in_tree)
    A[keepc].dropna(subset=['log_itd', 'log_blen', 'struc', 'lightness', 'pilosity', 'log_hairiness_eu'], how='all').to_csv(os.path.join(DATA_OUT, 'species_traits_latitude_climate_analysed.csv'), index=False)
    T[[c for c in keepc if c in T.columns and c != 'in_tree']].dropna(subset=['log_itd', 'log_blen', 'struc', 'lightness', 'pilosity', 'log_hairiness_eu'], how='all').to_csv(
        os.path.join(DATA_OUT, 'species_traits_all_matched.csv'), index=False)
    # name matching table (all sources)
    o = S['ost_records'][['verbatimAcceptedNameUsage', 'acceptedNameUsageID', 'id_name', 'id_rank', 'sp_v', 'sp_id', 'species_final', 'how']].drop_duplicates('verbatimAcceptedNameUsage')
    o.to_csv(os.path.join(DATA_OUT, 'name_matching_ostwald2024.csv'), index=False)
    h = S['hp_all'][['hp_name', 'species', 'how']].rename(columns={'species': 'gbif_species'}); h.to_csv(os.path.join(DATA_OUT, 'name_matching_henriquezpiskulich2026.csv'), index=False)
    log('done', len(R), 'model rows')

if __name__ == '__main__':
    main()
