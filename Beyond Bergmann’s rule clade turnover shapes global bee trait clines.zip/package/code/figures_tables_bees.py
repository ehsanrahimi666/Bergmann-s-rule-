#!/usr/bin/env python3
"""figures_tables_bees.py -- manuscript figures (figures/), display tables (tables/) and supplementary files
(package/supplementary/) for the bee paper, built from the outputs of analysis_bees_final.py (analysis/results/).
Run after analysis_bees_final.py:  python3 figures_tables_bees.py"""
import os, re, json, sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(HERE, 'results'); RD = os.path.join(RES, 'data')
FIG, TAB = os.path.join(ROOT, 'figures'), os.path.join(ROOT, 'tables')
SUP = os.path.join(ROOT, 'package', 'supplementary')
for d in (FIG, TAB, SUP): os.makedirs(d, exist_ok=True)
SHARED = os.environ.get('PMLA_SHARED', '/home/claude/pmla/shared')  # folder with pmla_common.py and ne_110m_land.geojson
sys.path.insert(0, SHARED)
import pmla_common as pc
pc.SHARED = SHARED

# ------------------------------------------------------------------ style (CONVENTIONS.md)
CM = 1 / 2.54; FULL = 15.9 * CM; COL = 7.6 * CM
C_SP, C_AS, C_SPEC, C_GREY = '#2a6f97', '#c1121f', '#3a3a3a', '#8c8c8c'
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Liberation Serif', 'Times New Roman', 'DejaVu Serif'],
                     'mathtext.fontset': 'stix', 'font.size': 8, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
                     'legend.fontsize': 7, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
                     'xtick.major.size': 2.5, 'ytick.major.size': 2.5, 'axes.spines.top': False, 'axes.spines.right': False,
                     'legend.frameon': False, 'pdf.fonttype': 42, 'savefig.dpi': 300})
def plab(ax, s, x=None, y=1.03):
    ax.text(0.0 if x is None else x, y, f'({s})', transform=ax.transAxes, fontsize=9, fontweight='bold', va='bottom', ha='left' if x is None or x >= 0 else 'left')
FS = 7   # smallest text size (pt); figures are embedded at (or above) their drawn width, so no printed text is below 7 pt
def leg_above(ax, **kw):
    """legend in the space above the axes, right-aligned (the panel label is at the left): it never covers data"""
    kw = {'fontsize': FS, 'loc': 'lower right', 'borderaxespad': 0.0, 'handletextpad': 0.4, 'labelspacing': 0.3, 'columnspacing': 1.0, **kw}
    return ax.legend(bbox_to_anchor=(1.0, 1.02), **kw)
def layout_with_labels(fig, rows, **layout_kw):
    """tight_layout, with the panel labels of each row above everything drawn over its axes (legends placed with
    leg_above); a second tight_layout makes room for the labels, which are then placed at their final height"""
    fig.tight_layout(**layout_kw)
    for k in range(2):
        fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = []
        for axes, letters in rows:
            top = max(a.get_tightbbox(r).y1 for a in axes)
            for a, s_ in zip(axes, letters):
                texts.append(a.text(0.0, a.transAxes.inverted().transform((0, top))[1] + 0.01, f'({s_})', transform=a.transAxes,
                                    fontsize=9, fontweight='bold', va='bottom', ha='left'))
        if k == 0:
            fig.tight_layout(**layout_kw)
            for t in texts: t.remove()
def _bbox(fig):
    """bbox_inches='tight' plus the full extent of the x-axis labels (which 'tight' collapses to the axis width)"""
    from matplotlib.transforms import Bbox, TransformedBbox
    fig.canvas.draw(); r = fig.canvas.get_renderer()
    bbs = [fig.get_tightbbox(r)] + [TransformedBbox(a.xaxis.label.get_window_extent(r), fig.dpi_scale_trans.inverted()) for a in fig.axes if a.xaxis.label.get_text()]
    return Bbox.union(bbs).padded(0.1)
def save(fig, name):
    bb = _bbox(fig)
    fig.savefig(os.path.join(FIG, name + '.png'), dpi=300, bbox_inches=bb)
    fig.savefig(os.path.join(FIG, name + '.pdf'), bbox_inches=bb)
    if name.startswith('FigS'):
        fig.savefig(os.path.join(SUP, name + '.png'), dpi=300, bbox_inches=bb)
    plt.close(fig)

# ------------------------------------------------------------------ data
M = pd.read_csv(os.path.join(RES, 'all_models.csv'), low_memory=False)
AIC = pd.read_csv(os.path.join(RES, 'aic_latitude_vs_climate.csv'))
ACOV = pd.read_csv(os.path.join(RES, 'assemblage_coverage.csv'))
SP = pd.read_csv(os.path.join(RD, 'species_traits_latitude_climate_analysed.csv'))
SPEC = pd.read_csv(os.path.join(RD, 'ostwald2025_specimens_with_climate.csv'), low_memory=False)
def cells(tag): return pd.read_csv(os.path.join(RD, f'assemblage_cells_{tag}.csv'))
def get(level, trait, subset, model, term, formula=None):
    d = M[(M.level == level) & (M.trait == trait) & (M.subset == subset) & (M.model == model) & (M.term == term)]
    if formula is not None: d = d[d.predictor == formula]
    return d.iloc[0] if len(d) else None

# ------------------------------------------------------------------ Behrmann map helpers
R = pc.R_EARTH; PHI0 = np.deg2rad(30.0)
def proj(lon, lat):
    return R * np.deg2rad(np.asarray(lon, float)) * np.cos(PHI0), R * np.sin(np.deg2rad(np.asarray(lat, float))) / np.cos(PHI0)
YMIN, YMAX = proj(0, -58)[1], proj(0, 84)[1]; XMAX = proj(180, 0)[0]
LAND = [np.column_stack(proj(p[:, 0], p[:, 1])) for p in pc.land_polygons()]
def base_map(ax):
    for p in LAND: ax.fill(p[:, 0], p[:, 1], color='#e3e3e3', lw=0, zorder=0)
    for p in LAND: ax.plot(p[:, 0], p[:, 1], color='#9a9a9a', lw=0.25, zorder=2)
    ax.set_xlim(-XMAX, XMAX); ax.set_ylim(YMIN, YMAX); ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    for la in (-40, -20, 0, 20, 40, 60):
        y = proj(0, la)[1]; ax.axhline(y, color='#c8c8c8', lw=0.3, ls=':', zorder=0.5)
        ax.text(-XMAX * 1.005, y, f'{abs(la)}°{"N" if la > 0 else ("S" if la < 0 else "")}', fontsize=FS, ha='right', va='center', color='#666666')
def cell_squares(ax, df, col, cmap, vmin, vmax, km=110.0):
    ij = np.array([c.split('_') for c in df.cell.values], dtype=float)
    polys = [np.array([[i * km, j * km], [(i + 1) * km, j * km], [(i + 1) * km, (j + 1) * km], [i * km, (j + 1) * km]]) for i, j in ij]
    pcoll = PolyCollection(polys, array=df[col].values, cmap=cmap, edgecolors='none', zorder=1)
    pcoll.set_clim(vmin, vmax); ax.add_collection(pcoll); return pcoll
def binned(ax, x, y, edges, color, label=None, min_n=5, lw=1.1, ms=3.2, marker='o', z=5):
    d = pd.DataFrame({'x': x, 'y': y}).dropna(); d['b'] = pd.cut(d.x, edges, include_lowest=True)
    g = d.groupby('b', observed=True).y.agg(['mean', 'sem', 'size']); g = g[g['size'] >= min_n]
    mid = np.array([iv.mid for iv in g.index])
    ax.errorbar(mid, g['mean'], yerr=1.96 * g['sem'].fillna(0), fmt=marker + '-', color=color, ms=ms, lw=lw, capsize=1.5, label=label, zorder=z, elinewidth=0.7)
    return g
def fmt_p(p): return '< 0.001' if p < 0.001 else f'= {p:.3f}'

# ================================================================== Fig1 maps
itd = cells('log_itd_main_5_spp'); st = cells('struc_main_5_spp')
fig, axs = plt.subplots(3, 1, figsize=(FULL, FULL * 1.02))
for ax, (df, col, cmap, lab, fmt) in zip(axs, [(itd, 'log_itd_mean', 'viridis', 'Mean ITD (mm)', 'mm'),
                                               (st, 'struc_mean', 'cividis', 'Share of species with\nstructural colour', 'share'),
                                               (itd, 'bshare_all', 'viridis', 'Share of bee species\nthat are $Bombus$', 'share')]):
    base_map(ax)
    q = np.nanquantile(df[col], [0.02, 0.98])
    pcl = cell_squares(ax, df, col, cmap, q[0], q[1])
    cb = fig.colorbar(pcl, ax=ax, shrink=0.78, pad=0.01, aspect=18); cb.ax.tick_params(labelsize=FS)
    if fmt == 'mm':
        ticks = np.log10([1.2, 1.5, 2, 2.5, 3, 4]); ticks = ticks[(ticks >= q[0]) & (ticks <= q[1])]
        cb.set_ticks(ticks); cb.set_ticklabels([f'{10**t:.1f}' for t in ticks])
    cb.set_label(lab, fontsize=7)
for ax, s in zip(axs, 'abc'): plab(ax, s, x=0.035, y=0.97)
fig.subplots_adjust(hspace=0.04)
save(fig, 'Fig1')

# ================================================================== Fig2 species ITD vs |lat| and temperature
d = SP.dropna(subset=['log_itd', 'abslat_median', 'bio1_mean', 'genus', 'family']).copy()
d['gm_itd'] = d.groupby('genus').log_itd.transform('mean'); d['gm_lat'] = d.groupby('genus').abslat_median.transform('mean'); d['gm_t'] = d.groupby('genus').bio1_mean.transform('mean')
d['ng'] = d.groupby('genus').log_itd.transform('size')
dw = d[d.ng >= 2].copy(); dw['itd_w'] = dw.log_itd - dw.gm_itd; dw['lat_w'] = dw.abslat_median - dw.gm_lat; dw['t_w'] = dw.bio1_mean - dw.gm_t
fig, axs = plt.subplots(2, 2, figsize=(FULL, FULL * 0.84))
for ax, (xx, yy, df, xl, yl, edges, mods) in zip(axs.ravel(), [
        ('abslat_median', 'log_itd', d, 'Absolute latitude (°, range median)', 'ITD (mm, log$_{10}$ scale)', np.arange(0, 75, 5), [('OLS', 'abslat_median')]),
        ('bio1_mean', 'log_itd', d, 'Mean annual temperature (°C, range mean)', 'ITD (mm, log$_{10}$ scale)', np.arange(-10, 32, 3), [('OLS', 'bio1_mean')]),
        ('lat_w', 'itd_w', dw, 'Absolute latitude within genus (°)', 'ITD within genus (log$_{10}$ mm)', np.arange(-30, 32, 5), [('LMM', 'abslat_median'), ('PGLS', 'abslat_median')]),
        ('t_w', 'itd_w', dw, 'Temperature within genus (°C)', 'ITD within genus (log$_{10}$ mm)', np.arange(-15, 16, 2.5), [('LMM', 'bio1_mean'), ('PGLS', 'bio1_mean')])]):
    ax.scatter(df[xx], df[yy], s=2.5, color=C_SP, alpha=0.25, lw=0, rasterized=True)
    binned(ax, df[xx], df[yy], edges, 'k', min_n=8)
    xs = np.linspace(np.nanquantile(df[xx], 0.01), np.nanquantile(df[xx], 0.99), 20)
    for (mod, term), ls in zip(mods, ['-', '--']):
        r = get('species', 'log_itd', 'all', mod, term)
        if r is None: continue
        b = r.estimate; a = df[yy].mean() - b * df[xx].mean()
        ax.plot(xs, a + b * xs, color=C_SP, lw=1.6, ls=ls, zorder=6,
                label=f'{mod}: {r.pct_change_unit:+.1f}% {"per 10°" if "abslat" in term else "per °C"} (p {fmt_p(r.p)})')
    leg_above(ax, handlelength=1.8)
    ax.set_xlabel(xl); ax.set_ylabel(yl)
    if yy == 'log_itd':
        tk = np.log10([0.5, 1, 2, 4, 8]); ax.set_yticks(tk); ax.set_yticklabels(['0.5', '1', '2', '4', '8'])
layout_with_labels(fig, [(axs[0], 'ab'), (axs[1], 'cd')], w_pad=1.5, h_pad=1.2)
save(fig, 'Fig2')

# ================================================================== Fig3 assemblage ITD with/without Bombus
same = cells('log_itd_same_cells'); bo = cells('log_itd_Bombus_only_5_spp')
fig, axs = plt.subplots(2, 2, figsize=(FULL, FULL * 0.84))
ax = axs[0, 0]; e = np.arange(0, 76, 5)
ax.scatter(same.abslat, same.log_itd_mean, s=2, color=C_AS, alpha=0.18, lw=0, rasterized=True)
ax.scatter(same.abslat, same.itd_nobombus, s=2, color=C_GREY, alpha=0.18, lw=0, rasterized=True)
for yy, col, lab, sub in [('log_itd_mean', C_AS, 'All bees', 'same cells: all bees'), ('itd_nobombus', C_SPEC, 'Without $Bombus$', 'same cells: without Bombus')]:
    r = get('assemblage', 'log_itd', sub, 'SAR error', 'abslat', 'abslat')
    binned(ax, same.abslat, same[yy], e, col, label=f'{lab} (SAR {r.pct_change_unit:+.1f}% per 10°, p {fmt_p(r.p)})', min_n=10)
tk = np.log10([1.5, 2, 2.5, 3, 4]); ax.set_yticks(tk); ax.set_yticklabels(['1.5', '2', '2.5', '3', '4'])
ax.set_xlabel('Absolute latitude of cell (°)'); ax.set_ylabel('Assemblage mean ITD (mm, log$_{10}$ scale)'); leg_above(ax)
ax = axs[0, 1]
ax.scatter(same.abslat, same.bshare_all, s=2, color=C_AS, alpha=0.18, lw=0, rasterized=True)
binned(ax, same.abslat, same.bshare_all, e, C_AS, min_n=10)
ax.set_xlabel('Absolute latitude of cell (°)'); ax.set_ylabel('$Bombus$ share of bee species in cell')
ax = axs[1, 0]
sc = ax.scatter(same.bshare_all, same.log_itd_mean, c=same.abslat, s=3, cmap='viridis', lw=0, alpha=0.6, rasterized=True)
binned(ax, same.bshare_all, same.log_itd_mean, np.linspace(0, 0.8, 17), 'k', min_n=10)
cb = fig.colorbar(sc, ax=ax, pad=0.01, aspect=25); cb.set_label('Absolute latitude (°)', fontsize=7); cb.ax.tick_params(labelsize=FS)
ax.set_yticks(tk); ax.set_yticklabels(['1.5', '2', '2.5', '3', '4'])
ax.set_xlabel('$Bombus$ share of bee species in cell'); ax.set_ylabel('Assemblage mean ITD (mm, log$_{10}$ scale)')
ax = axs[1, 1]
ax.scatter(bo.abslat, bo.log_itd_mean, s=2.5, color=C_AS, alpha=0.25, lw=0, rasterized=True)
r = get('assemblage', 'log_itd', 'Bombus only (>=5 spp)', 'SAR error', 'abslat', 'abslat')
binned(ax, bo.abslat, bo.log_itd_mean, e, 'k', min_n=10, label=f'SAR {r.pct_change_unit:+.1f}% per 10°, p {fmt_p(r.p)}' if r is not None else None)
tk2 = np.log10([3.4, 3.6, 3.8, 4.0, 4.2, 4.4, 4.6]); ax.set_yticks(tk2); ax.set_yticklabels([f'{10**t:.1f}' for t in tk2])
ax.set_xlabel('Absolute latitude of cell (°)'); ax.set_ylabel('$Bombus$ assemblage mean ITD (mm, log$_{10}$ scale)'); leg_above(ax)
layout_with_labels(fig, [(axs[0], 'ab'), (axs[1], 'cd')], w_pad=1.5, h_pad=1.2)
save(fig, 'Fig3')

# ================================================================== Fig4 family / genus forest plot (% ITD change per 10 deg)
def pct(r): return (r.pct_change_unit, r.pct_ci_lo, r.pct_ci_hi) if r is not None and np.isfinite(r.estimate) else (np.nan,) * 3
FAMS = ['Apidae', 'Halictidae', 'Andrenidae', 'Megachilidae', 'Colletidae', 'Melittidae']
gen_rows = M[(M.level == 'species') & (M.trait == 'log_itd') & M.subset.str.startswith('genus: ') & (M.model == 'OLS') & (M.term == 'abslat_median')]
GENS = [s.replace('genus: ', '') for s in gen_rows.sort_values('n', ascending=False).subset if s.count(' ') == 1]
groups = [('All bees', 'all', 'main (>=5 spp)')] + [(f, f'family: {f}', f'family: {f}') for f in FAMS] + [(g, f'genus: {g}', f'genus: {g}') for g in GENS]
fig, axs = plt.subplots(1, 2, figsize=(FULL, FULL * 0.78), sharey=True)
XL = {'sp': (-32, 42), 'as': (-14, 24)}
for ax, (models, key) in zip(axs, [((('OLS', '#9cc3da', 's', 'Species, OLS'), ('LMM', '#4f8fb8', '^', 'Species, LMM (families)'), ('PGLS', C_SP, 'o', 'Species, PGLS')), 'sp'),
                                    ((('SAR error', C_AS, 'D', 'Assemblages, SAR'),), 'as')]):
    lo_, hi_ = XL[key]
    for k, (lab, ssub, asub) in enumerate(groups):
        yk = -k; nlab = None
        for j, (mod, col, mk, ml) in enumerate(models):
            if mod == 'SAR error': r = get('assemblage', 'log_itd', asub, mod, 'abslat', 'abslat')
            else: r = get('species', 'log_itd', ssub, mod, 'abslat_median')
            e_, lo, hi = pct(r)
            if not np.isfinite(e_): continue
            off = (j - (len(models) - 1) / 2) * 0.26
            loc, hic = max(lo, lo_), min(hi, hi_)
            ax.errorbar(min(max(e_, lo_), hi_), yk + off, xerr=[[max(e_ - loc, 0)], [max(hic - e_, 0)]], fmt=mk, color=col, ms=3.0, lw=0.9, capsize=1.2,
                        label=ml if ml not in [h.get_label() for h in ax.get_legend_handles_labels()[0]] else None, mfc=col if r.p < 0.05 else 'white', zorder=4)
            if hi > hi_: ax.annotate('', xy=(hi_, yk + off), xytext=(hi_ - 3, yk + off), arrowprops=dict(arrowstyle='->', color=col, lw=0.8))
            if lo < lo_: ax.annotate('', xy=(lo_, yk + off), xytext=(lo_ + 3, yk + off), arrowprops=dict(arrowstyle='->', color=col, lw=0.8))
            if mod in ('PGLS', 'SAR error') or nlab is None: nlab = int(r.n)
        if nlab is not None: ax.text(1.01, yk, f'{nlab}', transform=ax.get_yaxis_transform(), fontsize=FS, va='center', color='#555555')
    ax.set_xlim(lo_, hi_)
    ax.axvline(0, color='k', lw=0.6); ax.axhline(-0.5, color='#bbbbbb', lw=0.5); ax.axhline(-len(FAMS) - 0.5, color='#bbbbbb', lw=0.5)
    ax.set_xlabel('Change in ITD per 10° of absolute latitude (%)' if key == 'sp' else 'Change in assemblage mean ITD per 10° (%)')
axs[0].set_yticks([-k for k in range(len(groups))]); axs[0].set_yticklabels([g[0] for g in groups], fontsize=FS)
for tl in axs[0].get_yticklabels():
    if tl.get_text() not in ('All bees',) + tuple(FAMS): tl.set_fontstyle('italic')
axs[0].set_ylim(-len(groups) + 0.5, 0.6)
for a_, s in zip(axs, 'ab'): plab(a_, s)
hh, ll = [], []
for a_ in axs:
    h_, l_ = a_.get_legend_handles_labels(); hh += h_; ll += l_
fig.tight_layout(w_pad=3.0, rect=(0, 0.035, 1, 1))
fig.legend(hh, ll, loc='lower center', ncol=4, fontsize=FS, bbox_to_anchor=(0.5, -0.005))
save(fig, 'Fig4')

# ================================================================== Fig5 structural colour
import statsmodels.formula.api as smf, statsmodels.api as sm
fig, axs = plt.subplots(2, 2, figsize=(FULL, FULL * 0.78))
ax = axs[0, 0]; ds = SP.dropna(subset=['struc', 'abslat_median'])
e = np.arange(0, 71, 5); g = ds.assign(b=pd.cut(ds.abslat_median, e, include_lowest=True)).groupby('b', observed=True).struc.agg(['mean', 'size'])
g = g[g['size'] >= 10]; mid = [iv.mid for iv in g.index]; se_ = np.sqrt(g['mean'] * (1 - g['mean']) / g['size'])
ax.errorbar(mid, g['mean'], yerr=1.96 * se_, fmt='o', color=C_SP, ms=3, capsize=1.5, lw=0.8, label='Species (5° bins, 95% CI)')
gl = smf.glm('struc ~ abslat_median', ds, family=sm.families.Binomial()).fit(); xx = np.linspace(0, 68, 50)
ax.plot(xx, gl.predict(pd.DataFrame({'abslat_median': xx})), color=C_SP, lw=1.3, label='Logistic GLM')
ax.set_xlabel('Absolute latitude (°, range median)'); ax.set_ylabel('Share of species with structural colour'); ax.set_ylim(0, None); leg_above(ax, ncol=2)
ax = axs[0, 1]; ce = cells('struc_main_5_spp')
ax.scatter(ce.abslat, ce.struc_mean, s=2, color=C_AS, alpha=0.2, lw=0, rasterized=True)
binned(ax, ce.abslat, ce.struc_mean, np.arange(0, 76, 5), 'k', min_n=10)
ax.set_xlabel('Absolute latitude of cell (°)'); ax.set_ylabel('Assemblage share with structural colour')
rows = [('All bees', 'all', 'main (>=5 spp)'), ('N hemisphere', 'N hemisphere (>=90% cells N)', 'N hemisphere cells'), ('S hemisphere', 'S hemisphere (>=90% cells S)', 'S hemisphere cells')] + \
       [(f, f'family: {f}', f'family: {f}') for f in FAMS if f != 'Melittidae']   # no structurally coloured Melittidae
ax = axs[1, 0]
for k, (lab, ssub, asub) in enumerate(rows):
    for j, (mod, col, mk) in enumerate([('GEE logit (genus clusters, exchangeable)', C_SP, 'o'), ('GLM logit', '#9cc3da', 's')]):
        r = get('species', 'struc', ssub, mod, 'abslat_median')
        if r is None or not np.isfinite(r.se) or r.se > 1: continue
        orr, lo, hi = np.exp(10 * r.estimate), np.exp(10 * r.ci_lo), np.exp(10 * r.ci_hi)
        ax.errorbar(orr, -k + (0.13 if j == 0 else -0.13), xerr=[[orr - lo], [hi - orr]], fmt=mk, color=col, ms=3, capsize=1.2, lw=0.9,
                    mfc=col if r.p < 0.05 else 'white', label=('GEE (genus clusters)' if j == 0 else 'GLM') if k == 0 else None)
    r = get('species', 'struc', ssub, 'PGLS linear probability', 'abslat_median')
    if r is not None: ax.text(1.01, -k, f'{int(r.n)}', transform=ax.get_yaxis_transform(), fontsize=FS, va='center', color='#555555')
ax.axvline(1, color='k', lw=0.6); ax.set_xscale('log'); ax.set_xticks([0.25, 0.5, 1, 2]); ax.set_xticklabels(['0.25', '0.5', '1', '2']); ax.minorticks_off()
ax.set_yticks([-k for k in range(len(rows))]); ax.set_yticklabels([r_[0] for r_ in rows], fontsize=FS)
ax.set_xlabel('Odds ratio of structural colour per 10° |lat|'); leg_above(ax, ncol=2)  # above the panel: no overlap with the markers
ax = axs[1, 1]
for k, (lab, ssub, asub) in enumerate(rows):
    r = get('assemblage', 'struc', asub, 'SAR error', 'abslat', 'abslat')
    if r is None or not np.isfinite(r.p): continue
    ax.errorbar(r.slope_unit, -k, xerr=[[r.slope_unit - r.ci_lo_unit], [r.ci_hi_unit - r.slope_unit]], fmt='D', color=C_AS, ms=3, capsize=1.2, lw=0.9, mfc=C_AS if r.p < 0.05 else 'white',
                label='Assemblages, SAR' if k == 0 else None)
    ax.text(1.01, -k, f'{int(r.n)}', transform=ax.get_yaxis_transform(), fontsize=FS, va='center', color='#555555')
ax.axvline(0, color='k', lw=0.6); ax.set_yticks([-k for k in range(len(rows))]); ax.set_yticklabels([r_[0] for r_ in rows], fontsize=FS)
ax.set_xlabel('Change in share with structural colour per 10° |lat|'); leg_above(ax)
layout_with_labels(fig, [(axs[0], 'ab'), (axs[1], 'cd')], w_pad=2.0, h_pad=1.5)
save(fig, 'Fig5')

# ================================================================== Fig6 lightness / pilosity / hairiness vs climate
sx = SPEC.dropna(subset=['bio1', 'bio5', 'bio12', 'lightness', 'pilosity'])
fig, axs = plt.subplots(2, 3, figsize=(FULL, FULL * 0.72))
for (i, j), (xx, yy, xl, yl, edges, term) in zip([(0, 0), (0, 1), (1, 0), (1, 1)], [
        ('bio5', 'lightness', 'Max. temperature of warmest month (°C)', 'Lightness (0–255)', np.arange(8, 44, 4), 'bio5'),
        ('abslat', 'lightness', 'Absolute latitude of specimen (°)', 'Lightness (0–255)', np.arange(0, 56, 5), 'abslat'),
        ('bio5', 'pilosity', 'Max. temperature of warmest month (°C)', 'Pilosity (proportion of pixels)', np.arange(8, 44, 4), 'bio5'),
        ('abslat', 'pilosity', 'Absolute latitude of specimen (°)', 'Pilosity (proportion of pixels)', np.arange(0, 56, 5), 'abslat')]):
    ax = axs[i, j]
    ax.scatter(sx[xx], sx[yy], s=3, color=C_SPEC, alpha=0.35, lw=0, rasterized=True)
    binned(ax, sx[xx], sx[yy], edges, C_SPEC, min_n=8)
    r = get('specimen', yy, 'Ostwald 2025 females', 'LMM', term)
    ro = get('specimen', yy, 'Ostwald 2025 females', 'OLS', term)
    xs_ = np.linspace(sx[xx].quantile(0.02), sx[xx].quantile(0.98), 20)
    if ro is not None: ax.plot(xs_, sx[yy].mean() + ro.estimate * (xs_ - sx[xx].mean()), color=C_GREY, lw=1.0, ls='--', label=f'OLS p {fmt_p(ro.p)}')
    if r is not None: ax.plot(xs_, sx[yy].mean() + r.estimate * (xs_ - sx[xx].mean()), color=C_SPEC, lw=1.3, label=f'LMM p {fmt_p(r.p)}')
    leg_above(ax, ncol=2, handlelength=1.8); ax.set_xlabel(xl); ax.set_ylabel(yl)
ax = axs[0, 2]
ha = cells('log_hairiness_eu_main_5_spp'); hnb = cells('log_hairiness_eu_no_Bombus_own_cells'); ha = ha[ha.cell.isin(hnb.cell)]
for df, yy, col, lab, sub in [(ha, 'log_hairiness_eu_mean', C_AS, 'All bees', 'same cells as no-Bombus'), (hnb, 'log_hairiness_eu_mean', C_SPEC, 'Without $Bombus$', 'no Bombus (same cells)')]:
    ax.scatter(df.abslat, df[yy], s=2, color=col, alpha=0.15, lw=0, rasterized=True)
    r = get('assemblage', 'log_hairiness_eu', sub, 'SAR error', 'abslat', 'abslat')
    binned(ax, df.abslat, df[yy], np.arange(34, 72, 3), col, min_n=8, label=f'{lab}: {r.pct_change_unit:+.0f}%/10°, p {fmt_p(r.p)}' if r is not None else lab)
ax.set_xlabel('Absolute latitude of cell (°)'); ax.set_ylabel('Hairiness index, cell mean (log$_{10}$)'); leg_above(ax, handlelength=1.5)
ax = axs[1, 2]
dh = SP.dropna(subset=['log_hairiness_eu', 'abslat_median'])
ax.scatter(dh.abslat_median, dh.log_hairiness_eu, s=4, color=C_SP, alpha=0.4, lw=0)
ax.scatter(dh[dh.genus == 'Bombus'].abslat_median, dh[dh.genus == 'Bombus'].log_hairiness_eu, s=7, color='#e09f3e', lw=0, label='$Bombus$')
binned(ax, dh.abslat_median, dh.log_hairiness_eu, np.arange(20, 72, 5), 'k', min_n=8)
ax.set_xlabel('Absolute latitude (°, range median)'); ax.set_ylabel('Hairiness index, species (log$_{10}$)'); leg_above(ax)
layout_with_labels(fig, [(axs[0], 'abc'), (axs[1], 'def')], w_pad=1.0, h_pad=1.2)
save(fig, 'Fig6')

# ================================================================== FigS1 coverage
fig = plt.figure(figsize=(FULL, FULL * 0.72)); gs = fig.add_gridspec(2, 2, height_ratios=[1.25, 1], hspace=0.6, wspace=0.3)
ax = fig.add_subplot(gs[0, :]); base_map(ax); pcl = cell_squares(ax, itd, 'coverage', 'cividis', 0, 1)
cb = fig.colorbar(pcl, ax=ax, shrink=0.8, pad=0.01); cb.set_label('Share of GBIF species\nwith ITD data', fontsize=7); cb.ax.tick_params(labelsize=FS); plab(ax, 'a', x=0, y=0.98)
ax = fig.add_subplot(gs[1, 0])
for c, lab, col in [('log_itd', 'ITD', C_SP), ('log_blen', 'Body length', '#6a994e'), ('struc', 'Structural colour', '#bc6c25'), ('lightness', 'Lightness/pilosity', C_SPEC), ('log_hairiness_eu', 'Hairiness (Europe)', '#9d4edd')]:
    v = SP.dropna(subset=[c]).lat_median
    ax.hist(v, bins=np.arange(-50, 76, 5), histtype='step', color=col, lw=1.0, label=f'{lab} (n={len(v)})')
ax.set_xlabel('Range-median latitude (°)'); ax.set_ylabel('Species'); leg_above(ax, handlelength=1.5); axb = ax
ax = fig.add_subplot(gs[1, 1])
ax.scatter(itd.abslat, itd.coverage, s=2, color=C_AS, alpha=0.25, lw=0, rasterized=True); binned(ax, itd.abslat, itd.coverage, np.arange(0, 76, 5), 'k', min_n=10)
ax.set_xlabel('Absolute latitude of cell (°)'); ax.set_ylabel('ITD coverage of cell'); axc = ax
fig.canvas.draw(); r_ = fig.canvas.get_renderer(); top_ = max(a.get_tightbbox(r_).y1 for a in (axb, axc))
for a, s_ in ((axb, 'b'), (axc, 'c')): plab(a, s_, y=a.transAxes.inverted().transform((0, top_))[1] + 0.01)
save(fig, 'FigS1')

# ================================================================== FigS2 nonlinearity (species + assemblage ITD)
fig, axs = plt.subplots(1, 2, figsize=(FULL * 0.99, FULL * 0.36))
for ax, (df, x, y, lev, col, sub, mod) in zip(axs, [(SP.dropna(subset=['log_itd']), 'abslat_median', 'log_itd', 'species', C_SP, 'all', 'OLS quadratic'),
                                                    (itd, 'abslat', 'log_itd_mean', 'assemblage', C_AS, 'main (>=5 spp)', 'SAR error quadratic')]):
    ax.scatter(df[x], df[y], s=2, color=col, alpha=0.18, lw=0, rasterized=True); binned(ax, df[x], df[y], np.arange(0, 76, 5), 'k', min_n=8)
    b2 = np.polyfit(df[x], df[y], 2); xx = np.linspace(df[x].min(), df[x].max(), 60); ax.plot(xx, np.polyval(b2, xx), color=col, lw=1.3)
    r = get(lev, 'log_itd', sub, mod, 'abslat_c2')
    if r is not None: ax.text(0.09, 1.03, f'quadratic term p {fmt_p(r.p)}; ΔAIC {r.dAIC_vs_linear:.1f}; vertex {r.vertex_deg:.0f}°', transform=ax.transAxes, fontsize=FS, va='bottom')
    ax.set_xlabel('Absolute latitude (°)'); ax.set_ylabel(('Species' if lev == 'species' else 'Assemblage mean') + ' ITD (log$_{10}$ mm)')
for a_, s in zip(axs, 'ab'): plab(a_, s)
fig.tight_layout(); save(fig, 'FigS2')

# ================================================================== FigS3 ITD sensitivity forest (species LMM/PGLS + assemblage SAR)
sens_sp = ['all', 'females only (no BeeFunc/unknown sex)', 'no eusocial species', 'no Bombus', 'no brood parasites', 'no introduced', '>=10 cells', '>=2 ITD sources',
           'EuPollTrait/BeeFunc value only', 'Ostwald 2024 value only', 'first-pass Ostwald name assignment', 'lat_mid instead of median',
           'N hemisphere (>=90% cells N)', 'S hemisphere (>=90% cells S)', 'W Palaearctic species', 'W Palaearctic species, females only', 'Nearctic species',
           'Nearctic species, no Bombus', 'Nearctic species, females only', 'Neotropical species']
sens_as = ['main (>=5 spp)', '>=10 spp', 'coverage >=0.3', 'coverage >=0.5', 'no introduced', 'females-only ITD', 'no eusocial species', 'no Bombus (own cells)',
           'first-pass Ostwald names', 'N hemisphere cells', 'S hemisphere cells', 'region: W Palaearctic', 'region: Nearctic', 'region: Neotropics', 'region: Tropics (|lat|<23.4)']
fig, axs = plt.subplots(1, 2, figsize=(FULL, FULL * 0.62))
ax = axs[0]
for k, sub in enumerate(sens_sp):
    for j, (mod, col, mk) in enumerate([('LMM', '#5e9fc4', 's'), ('PGLS', C_SP, 'o')]):
        r = get('species', 'log_itd', sub, mod, 'abslat_median')
        if r is None: continue
        ax.errorbar(r.pct_change_unit, -k + (j - 0.5) * 0.3, xerr=[[r.pct_change_unit - r.pct_ci_lo], [r.pct_ci_hi - r.pct_change_unit]], fmt=mk, color=col, ms=3, capsize=1.2, lw=0.8,
                    mfc=col if r.p < 0.05 else 'white', label=mod if k == 0 else None)
# display labels for the subsets (manuscript wording; the subset codes are those of all_models.csv)
SENS_LAB = {'all': 'All species', 'females only (no BeeFunc/unknown sex)': 'Females only', 'no eusocial species': 'No eusocial species',
            'no Bombus': 'No $Bombus$', 'no brood parasites': 'No brood parasites', 'no introduced': 'No introduced species',
            '>=10 cells': '≥10 occupied cells', '>=2 ITD sources': '≥2 ITD sources', 'EuPollTrait/BeeFunc value only': 'EuPollTrait/BeeFunc ITD only',
            'Ostwald 2024 value only': 'Ostwald et al. (2024) ITD only', 'first-pass Ostwald name assignment': 'Key-based Ostwald names',
            'lat_mid instead of median': 'Mid-range latitude', 'N hemisphere (>=90% cells N)': 'Northern Hemisphere species',
            'S hemisphere (>=90% cells S)': 'Southern Hemisphere species', 'W Palaearctic species': 'West Palaearctic',
            'W Palaearctic species, females only': 'West Palaearctic, females only', 'Nearctic species': 'Nearctic',
            'Nearctic species, no Bombus': 'Nearctic, no $Bombus$', 'Nearctic species, females only': 'Nearctic, females only',
            'Neotropical species': 'Neotropics',
            'main (>=5 spp)': 'All cells (≥5 species)', '>=10 spp': '≥10 species', 'coverage >=0.3': 'Coverage ≥0.3', 'coverage >=0.5': 'Coverage ≥0.5',
            'females-only ITD': 'Females-only ITD', 'no Bombus (own cells)': 'No $Bombus$', 'first-pass Ostwald names': 'Key-based Ostwald names',
            'N hemisphere cells': 'Northern Hemisphere cells', 'S hemisphere cells': 'Southern Hemisphere cells', 'region: W Palaearctic': 'West Palaearctic',
            'region: Nearctic': 'Nearctic', 'region: Neotropics': 'Neotropics', 'region: Tropics (|lat|<23.4)': 'Tropics (|lat| < 23.4°)'}
ax.set_yticks(-np.arange(len(sens_sp))); ax.set_yticklabels([SENS_LAB.get(s_, s_) for s_ in sens_sp], fontsize=FS); ax.axvline(0, color='k', lw=0.6); ax.legend(fontsize=FS, loc='upper right')
ax.set_xlabel('Species: change in ITD per 10° |lat| (%)')
ax = axs[1]
for k, sub in enumerate(sens_as):
    r = get('assemblage', 'log_itd', sub, 'SAR error', 'abslat', 'abslat')
    if r is None: continue
    ax.errorbar(r.pct_change_unit, -k, xerr=[[r.pct_change_unit - r.pct_ci_lo], [r.pct_ci_hi - r.pct_change_unit]], fmt='D', color=C_AS, ms=3, capsize=1.2, lw=0.8, mfc=C_AS if r.p < 0.05 else 'white')
    ax.text(1.01, -k, f'{int(r.n)}', transform=ax.get_yaxis_transform(), fontsize=FS, va='center', color='#555555')
ax.set_yticks(-np.arange(len(sens_as))); ax.set_yticklabels([SENS_LAB.get(s_, s_) for s_ in sens_as], fontsize=FS); ax.axvline(0, color='k', lw=0.6)
ax.set_xlabel('Assemblages: change in mean ITD per 10° (%)')
for a_, s in zip(axs, 'ab'): plab(a_, s, x=-0.02)
fig.tight_layout(w_pad=2, rect=(0, 0, 0.97, 1)); save(fig, 'FigS3')  # rect: keeps the x-label of (b) inside the canvas

# ================================================================== FigS5 other assemblage maps
fig, axs = plt.subplots(4, 1, figsize=(FULL, FULL * 1.3))
for ax, (tag, col, lab, cmap) in zip(axs.ravel(), [('log_blen_main_5_spp', 'log_blen_mean', 'Mean body length\n(log$_{10}$ mm)', 'viridis'),
                                                   ('lightness_main_5_spp', 'lightness_mean', 'Mean lightness\n(0–255)', 'cividis'),
                                                   ('pilosity_main_5_spp', 'pilosity_mean', 'Mean pilosity\n(proportion)', 'viridis'),
                                                   ('log_itd_no_Bombus_own_cells', 'log_itd_mean', 'Mean ITD without\n$Bombus$ (log$_{10}$ mm)', 'viridis')]):
    df = cells(tag); base_map(ax); q = np.nanquantile(df[col], [0.02, 0.98]); pcl = cell_squares(ax, df, col, cmap, q[0], q[1])
    cb = fig.colorbar(pcl, ax=ax, shrink=0.75, pad=0.01); cb.set_label(lab, fontsize=FS); cb.ax.tick_params(labelsize=FS)
for a_, s in zip(axs.ravel(), 'abcd'): plab(a_, s, x=0, y=0.97)
fig.subplots_adjust(hspace=0.06); save(fig, 'FigS5')

# ================================================================== FigS4 hemisphere-specific slopes (species + assemblage)
fig, ax = plt.subplots(figsize=(COL * 1.35, COL * 1.0))
rows = [('Species N (PGLS)', 'species', 'N hemisphere (>=90% cells N)', 'PGLS', 'abslat_median', C_SP), ('Species S (PGLS)', 'species', 'S hemisphere (>=90% cells S)', 'PGLS', 'abslat_median', C_SP),
        ('Species N (LMM)', 'species', 'N hemisphere (>=90% cells N)', 'LMM', 'abslat_median', '#5e9fc4'), ('Species S (LMM)', 'species', 'S hemisphere (>=90% cells S)', 'LMM', 'abslat_median', '#5e9fc4'),
        ('Assemblages N (SAR)', 'assemblage', 'N hemisphere cells', 'SAR error', 'abslat', C_AS), ('Assemblages S (SAR)', 'assemblage', 'S hemisphere cells', 'SAR error', 'abslat', C_AS)]
for k, (lab, lev, sub, mod, term, col) in enumerate(rows):
    r = get(lev, 'log_itd', sub, mod, term, 'abslat' if lev == 'assemblage' else None)
    if r is None: continue
    ax.errorbar(r.pct_change_unit, -k, xerr=[[r.pct_change_unit - r.pct_ci_lo], [r.pct_ci_hi - r.pct_change_unit]], fmt='o', color=col, ms=3, capsize=1.2, lw=0.8, mfc=col if r.p < 0.05 else 'white')
    ax.text(1.01, -k, f'n={int(r.n)}', transform=ax.get_yaxis_transform(), fontsize=FS, va='center')
ax.set_yticks(-np.arange(len(rows))); ax.set_yticklabels([r_[0] for r_ in rows], fontsize=FS); ax.axvline(0, color='k', lw=0.6)
ax.set_xlabel('Change in ITD per 10° |lat| (%)'); fig.tight_layout(); save(fig, 'FigS4')
print('figures done')

# ================================================================== TABLES
def r3(x, sig=3):
    if x is None or (isinstance(x, float) and not np.isfinite(x)): return ''
    if x == 0: return '0'
    return f'{x:.{sig}g}' if abs(x) < 1e4 else f'{x:.0f}'
def pstr(p): return '' if not np.isfinite(p) else ('<0.001' if p < 0.001 else f'{p:.3f}')
TRL = {'log_itd': 'ITD (log10 mm)', 'log_blen': 'Body length (log10 mm)', 'lightness': 'Lightness (0-255)', 'pilosity': 'Pilosity (proportion)',
       'log_hairiness_eu': 'Hairiness index, Europe (log10)', 'struc': 'Structural colour (0/1)', 'bombus_share': 'Bombus share'}
def disp(r, extra=()):
    out = {'Trait': TRL.get(r.trait, r.trait), 'Subset': r.subset, 'Model': r.model, 'Predictor': r.term.replace('abslat_median', '|lat|').replace('abslat', '|lat|').replace('bio1_mean', 'bio1'),
           'Unit': r.unit, 'n': int(r.n) if np.isfinite(r.n) else '', 'Slope': r3(r.slope_unit), 'SE': r3(r.se_unit), '95% CI': f'{r3(r.ci_lo_unit)} to {r3(r.ci_hi_unit)}',
           'p': pstr(r.p), '% change': r3(r.pct_change_unit, 2) if 'pct_change_unit' in r and np.isfinite(r.pct_change_unit) else '',
           'Std. effect': r3(r.std_effect, 2) if 'std_effect' in r and np.isfinite(r.std_effect) else ''}
    for c, lab in extra:
        v = r.get(c, np.nan); out[lab] = r3(v, 3) if isinstance(v, (float, int, np.floating)) and np.isfinite(v) else ('' if not isinstance(v, str) else v)
    return out
# Table 2 species
t2 = []
for y in ['log_itd', 'log_blen', 'lightness', 'pilosity', 'log_hairiness_eu']:
    for term in ['abslat_median', 'bio1_mean']:
        for mod in ['OLS', 'LMM', 'PGLS']:
            r = get('species', y, 'all', mod, term)
            if r is not None: t2.append(disp(r, [('pagel_lambda', 'Pagel λ'), ('r2', 'R²'), ('genus_var', 'Genus variance')]))
for term in ['abslat_median', 'bio1_mean']:
    for mod in ['GLM logit', 'GEE logit (genus clusters, exchangeable)', 'PGLS linear probability']:
        r = get('species', 'struc', 'all', mod, term)
        if r is not None: t2.append(disp(r, [('pagel_lambda', 'Pagel λ'), ('prevalence', 'Prevalence')]))
for y in ['lightness', 'pilosity']:
    for term in ['abslat', 'bio1', 'bio5']:
        for mod in ['OLS', 'LMM']:
            r = get('specimen', y, 'Ostwald 2025 females', mod, term)
            if r is not None: t2.append(disp(r, [('genus_var', 'Genus variance')]) | {'Subset': 'specimens (Ostwald 2025)'})
T2 = pd.DataFrame(t2); T2.to_csv(os.path.join(TAB, 'Table2_species_models.csv'), index=False)
# Table 3 assemblage
t3 = []
for y in ['log_itd', 'log_blen', 'struc', 'lightness', 'pilosity', 'log_hairiness_eu']:
    for f in ['abslat', 'bio1']:
        r = get('assemblage', y, 'main (>=5 spp)', 'SAR error', f, f)
        if r is not None: t3.append(disp(r, [('sar_lambda', 'SAR λ'), ('moran_I_ols', "Moran's I (OLS resid.)"), ('moran_I_sar', "Moran's I (SAR resid.)"), ('pseudo_r2', 'Pseudo-R²'), ('median_coverage', 'Median coverage')]))
for sub, y, f, term in [('same cells: all bees', 'log_itd', 'abslat', 'abslat'), ('same cells: without Bombus', 'log_itd', 'abslat', 'abslat'),
                        ('same cells: all bees', 'log_itd', 'abslat + bshare_all', 'abslat'), ('same cells: all bees', 'log_itd', 'abslat + bshare_all', 'bshare_all'),
                        ('same cells: Bombus share (all GBIF spp)', 'bombus_share', 'abslat', 'abslat'),
                        ('Bombus only (>=5 spp)', 'log_itd', 'abslat', 'abslat'), ('Bombus only (>=5 spp)', 'log_itd', 'bio1', 'bio1'),
                        ('no Bombus (same cells)', 'log_hairiness_eu', 'abslat', 'abslat'), ('no Bombus (same cells)', 'struc', 'abslat', 'abslat')]:
    r = get('assemblage', y, sub, 'SAR error', term, f)
    if r is not None: t3.append(disp(r, [('sar_lambda', 'SAR λ'), ('moran_I_ols', "Moran's I (OLS resid.)"), ('moran_I_sar', "Moran's I (SAR resid.)"), ('pseudo_r2', 'Pseudo-R²')]) | {'Subset': sub + (f' [{f}]' if '+' in f else '')})
T3 = pd.DataFrame(t3); T3.to_csv(os.path.join(TAB, 'Table3_assemblage_models.csv'), index=False)
# Table 4 family / genus
t4 = []
for lab, ssub, asub in groups:
    row = {'Group': lab if lab in ['All bees'] + FAMS else f'*{lab}*', 'Level': 'family' if lab in FAMS else ('all' if lab == 'All bees' else 'genus')}
    for mod, key in [('OLS', 'OLS'), ('LMM', 'LMM'), ('PGLS', 'PGLS')]:
        r = get('species', 'log_itd', ssub, mod, 'abslat_median')
        row[f'{key} n'] = int(r.n) if r is not None else ''
        row[f'{key} %/10°'] = f'{r3(r.pct_change_unit, 2)} ({r3(r.pct_ci_lo, 2)}, {r3(r.pct_ci_hi, 2)})' if r is not None else ''
        row[f'{key} p'] = pstr(r.p) if r is not None else ''
        if mod == 'PGLS': row['Pagel λ'] = r3(r.pagel_lambda, 2) if r is not None else ''
    r = get('species', 'log_itd', ssub, 'PGLS', 'bio1_mean')
    row['PGLS bio1 %/°C'] = f'{r3(r.pct_change_unit, 2)} (p {pstr(r.p)})' if r is not None else ''
    r = get('assemblage', 'log_itd', asub, 'SAR error', 'abslat', 'abslat')
    row['SAR cells'] = int(r.n) if r is not None else ''; row['SAR %/10°'] = f'{r3(r.pct_change_unit, 2)} ({r3(r.pct_ci_lo, 2)}, {r3(r.pct_ci_hi, 2)})' if r is not None else ''
    row['SAR p'] = pstr(r.p) if r is not None else ''
    t4.append(row)
T4 = pd.DataFrame(t4); T4.to_csv(os.path.join(TAB, 'Table4_family_genus.csv'), index=False)
# Supplementary tables (display + full precision)
M.to_csv(os.path.join(SUP, 'TableS1_all_models_full_precision.csv'), index=False)
AIC.to_csv(os.path.join(SUP, 'TableS4_AIC_latitude_vs_climate.csv'), index=False)
aic_d = []
for _, r in AIC.iterrows():
    for pre in ['OLS', 'LMM_ML', 'PGLS', 'SAR', 'GLM']:
        cols = [c for c in AIC.columns if c.startswith(pre + '_AIC_') and np.isfinite(r.get(c, np.nan))]
        if not cols: continue
        best = min(cols, key=lambda c: r[c])
        n_ = int(r.n_tree) if pre == 'PGLS' else int(r.n)  # PGLS rows were fitted on the species in the tree
        aic_d.append({'Trait': TRL.get(r.trait, r.trait), 'Subset': r.subset, 'n': n_, 'Model family': pre,
                      **{c.replace(pre + '_AIC_', 'ΔAIC '): r3(r[c] - r[best], 3) for c in cols}, 'Best': best.replace(pre + '_AIC_', '')})
pd.DataFrame(aic_d).to_csv(os.path.join(TAB, 'TableS4_AIC_latitude_vs_climate.csv'), index=False)
sens = M[(M.trait == 'log_itd') & (((M.level == 'species') & M.term.eq('abslat_median') & M.model.isin(['LMM', 'PGLS', 'OLS']) & ~M.subset.str.startswith(('genus', 'family', 'lifestyle', 'Europe')))
                                   | ((M.level == 'assemblage') & M.term.eq('abslat') & (M.predictor == 'abslat') & ~M.subset.str.startswith(('genus', 'family', 'lifestyle', 'same cells'))))]
pd.DataFrame([disp(r, [('pagel_lambda', 'Pagel λ'), ('sar_lambda', 'SAR λ'), ('moran_I_ols', "Moran's I")]) | {'Level': r.level} for _, r in sens.iterrows()]).to_csv(os.path.join(TAB, 'TableS5_ITD_sensitivity.csv'), index=False)
q = M[M.model.str.contains('quadratic') | M.subset.str.contains('hemisphere') | M.subset.str.contains('interaction')]
pd.DataFrame([disp(r, [('dAIC_vs_linear', 'ΔAIC vs linear'), ('vertex_deg', 'Vertex (°)'), ('pagel_lambda', 'Pagel λ')]) | {'Level': r.level} for _, r in q.iterrows()]).to_csv(os.path.join(TAB, 'TableS3_nonlinearity_hemispheres.csv'), index=False)
sc_ = M[(M.trait == 'struc')]
pd.DataFrame([disp(r, [('prevalence', 'Prevalence'), ('pagel_lambda', 'Pagel λ'), ('sar_lambda', 'SAR λ'), ('n_clusters', 'Clusters')]) | {'Level': r.level} for _, r in sc_.iterrows()]).to_csv(os.path.join(TAB, 'TableS8_structural_colour.csv'), index=False)
spm = M[M.level == 'specimen']
pd.DataFrame([disp(r, [('genus_var', 'Genus variance'), ('optimizer', 'Optimizer'), ('note', 'Note')]) for _, r in spm.iterrows()]).to_csv(os.path.join(TAB, 'TableS9_specimen_lightness_pilosity.csv'), index=False)
bm = M[M.subset.str.startswith(('same cells', 'Bombus only', 'genus: Bombus')) | (M.subset.str.contains('Bombus') & (M.trait.isin(['log_hairiness_eu', 'struc'])))]
pd.DataFrame([disp(r, [('sar_lambda', 'SAR λ'), ('pagel_lambda', 'Pagel λ'), ('aic', 'AIC')]) | {'Level': r.level, 'Formula': r.predictor} for _, r in bm.iterrows()]).to_csv(os.path.join(TAB, 'TableS7_Bombus.csv'), index=False)
ACOV.round(3).to_csv(os.path.join(TAB, 'TableS2_assemblage_coverage.csv'), index=False)
fg = M[M.subset.str.startswith(('family', 'genus', 'lifestyle', 'Europe sociality'))]
pd.DataFrame([disp(r, [('pagel_lambda', 'Pagel λ'), ('sar_lambda', 'SAR λ')]) | {'Level': r.level} for _, r in fg.iterrows()]).to_csv(os.path.join(TAB, 'TableS6_family_genus_lifestyle_all.csv'), index=False)
for f_ in ['name_matching_by_source.csv', 'analysed_species_by_trait.csv', 'trait_source_agreement.csv', 'ostwald2024_name_key_conflicts.csv']:
    pd.read_csv(os.path.join(RES, f_)).to_csv(os.path.join(SUP, 'data_' + f_), index=False)
for f_ in os.listdir(TAB):
    if f_.startswith('TableS'): pd.read_csv(os.path.join(TAB, f_)).to_csv(os.path.join(SUP, f_), index=False)
print('tables done')
