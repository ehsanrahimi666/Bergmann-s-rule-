#!/usr/bin/env python3
"""test_toolkit.py -- checks of the pmla_common functions used in the bee analysis on simulated data with a
known answer (tree_vcv, pgls, assemblages, sar_error) plus the fast variants used in analysis_bees_final.py.
Writes analysis/toolkit_tests.csv. Run: python3 test_toolkit.py"""
import sys, io, os, numpy as np, pandas as pd
SHARED = os.environ.get('PMLA_SHARED', '/home/claude/pmla/shared')  # folder with cell_climate_0.5deg.parquet (used by the assemblage test)
sys.path.insert(0, SHARED); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pmla_common as pc
pc.SHARED = SHARED
import dendropy
rng = np.random.default_rng(20260930)
ROWS = []
def rec(test, quantity, expected, got, tol, note=''):
    ok = bool(np.all(np.abs(np.asarray(expected, float) - np.asarray(got, float)) <= tol))
    ROWS.append(dict(test=test, quantity=quantity, expected=np.round(expected, 5) if np.ndim(expected) == 0 else str(np.round(expected, 4).tolist()),
                     got=np.round(got, 5) if np.ndim(got) == 0 else str(np.round(got, 4).tolist()), tolerance=tol, passed=ok, note=note))
    print(('PASS ' if ok else 'FAIL ') + f'{test}: {quantity} expected={expected} got={got}')

# ---------------------------------------------------------------- 1 tree_vcv on a hand-made tree
nwk = '((Aa_aa:1,Bb_bb:1):2,(Cc_cc:2,Dd_dd:1):1);'
t = dendropy.Tree.get(data=nwk, schema='newick', preserve_underscores=True, rooting='default-rooted')
names, V = pc.tree_vcv(t, {'Aa aa', 'Bb bb', 'Cc cc', 'Dd dd'})
o = [names.index(n) for n in ['Aa aa', 'Bb bb', 'Cc cc', 'Dd dd']]; V = V[np.ix_(o, o)]
Vexp = np.array([[3, 2, 0, 0], [2, 3, 0, 0], [0, 0, 3, 1], [0, 0, 1, 2]], float)
rec('tree_vcv', 'V (4 tips, known branch lengths)', Vexp, V, 1e-12)
names2, V2 = pc.tree_vcv(t, {'Aa aa', 'Cc cc'})
ix = [names2.index('Aa aa'), names2.index('Cc cc')]
rec('tree_vcv', 'pruned V (2 tips)', np.array([[3, 0], [0, 3]], float), V2[np.ix_(ix, ix)], 1e-12)

# ---------------------------------------------------------------- 2 PGLS on a simulated ultrametric tree
def yule_tree(n, seed):
    """pure-birth ultrametric tree with n tips (dendropy), tips named Gx_sN."""
    from dendropy.simulate import treesim
    import random
    random.seed(seed)
    tr = treesim.birth_death_tree(birth_rate=1.0, death_rate=0.0, num_extant_tips=n, rng=random.Random(seed))
    import string
    def word(i, k=3):
        a = string.ascii_lowercase; w = ''
        for _ in range(k): w = a[i % 26] + w; i //= 26
        return w
    for i, lf in enumerate(tr.leaf_node_iter()):
        lf.taxon.label = f'Gen{word(i % 40)}_sp{word(i)}'
        lf.edge.length = (lf.edge.length or 0.0) + 0.05   # the simulator ends on a split (zero-length tips); keeps ultrametric
    return tr
tr = yule_tree(400, 11)
nm, Vt = pc.tree_vcv(tr, {pc.clean_name(l.taxon.label) for l in tr.leaf_node_iter()})
Vt = Vt / np.diag(Vt).mean()
for lam_true in (1.0, 0.5, 0.0):
    est, lams, ses = [], [], []
    for rep in range(12):
        C = Vt * lam_true; np.fill_diagonal(C, 1.0)
        L = np.linalg.cholesky(C + 1e-10 * np.eye(len(nm)))
        x = L @ rng.normal(size=len(nm))            # phylogenetically structured predictor
        e = L @ rng.normal(size=len(nm)) * 0.5
        y = 1.0 + 0.3 * x + e
        df = pd.DataFrame({'species': nm, 'y': y, 'x': x})
        r = pc.pgls(df, 'y', ['x'], tr)
        est.append(r['table'].set_index('term').loc['x', 'estimate']); ses.append(r['table'].set_index('term').loc['x', 'se']); lams.append(r['lambda'])
    rec('pgls', f'mean slope over 12 sims (true 0.3, lambda={lam_true})', 0.3, np.mean(est), 0.03)
    rec('pgls', f'mean lambda over 12 sims (true {lam_true})', lam_true, np.mean(lams), 0.12)
    rec('pgls', f'SD of slope vs mean SE (lambda={lam_true})', np.std(est, ddof=1), np.mean(ses), max(0.5 * np.mean(ses), 0.01), 'SE calibration (loose)')
# exact agreement with a direct GLS at the ML lambda
import statsmodels.api as sm
C = Vt * 0.7; np.fill_diagonal(C, 1.0); L = np.linalg.cholesky(C)
x = L @ rng.normal(size=len(nm)); y = 2 + 0.2 * x + L @ rng.normal(size=len(nm)) * 0.4
df = pd.DataFrame({'species': nm, 'y': y, 'x': x})
r = pc.pgls(df, 'y', ['x'], tr); lam = r['lambda']
Cl = Vt * lam; np.fill_diagonal(Cl, 1.0)
g = sm.GLS(y, sm.add_constant(x), sigma=Cl).fit()
rec('pgls', 'slope equals statsmodels GLS at ML lambda', g.params[1], r['table'].estimate[1], 1e-8)
rec('pgls', 'SE equals statsmodels GLS at ML lambda', g.bse[1], r['table'].se[1], 1e-8)
# ML lambda equals the maximiser of the profile likelihood on a fine grid
def ll(lam):
    Cl = Vt * lam; np.fill_diagonal(Cl, 1.0); return sm.GLS(y, sm.add_constant(x), sigma=Cl).fit().llf
grid = np.linspace(0, 1, 201); lg = [ll(l_) for l_ in grid]
rec('pgls', 'lambda = argmax of profile logLik (0.005 grid)', grid[int(np.argmax(lg))], lam, 0.011)
rec('pgls', 'logLik equals statsmodels GLS llf', ll(lam), r['logLik'], 1e-6)
# fast eigen PGLS (used in the final script) equals pc.pgls
from analysis_bees_final import pgls_fast, register_tree
register_tree(tr)
rf = pgls_fast(df, 'y', ['x'], tr)
rec('pgls_fast', 'slope equals pc.pgls', r['table'].estimate[1], rf['table'].estimate[1], 1e-8)
rec('pgls_fast', 'lambda equals pc.pgls', r['lambda'], rf['lambda'], 1e-9)
rec('pgls_fast', 'logLik equals pc.pgls', r['logLik'], rf['logLik'], 1e-6)

# ---------------------------------------------------------------- 3 assemblages on a synthetic cube
cube = pd.DataFrame({'species': ['A a', 'B b', 'C c', 'D d', 'E e', 'A a', 'B b', 'F f'],
                     'gcol': [360, 360, 360, 360, 360, 361, 361, 361], 'grow': [80, 80, 80, 80, 80, 80, 80, 80], 'n': 1})
# gcol 360/361 -> lon 0.25/0.75 ; grow 80 -> lat 49.75 : both 0.5-deg cells fall in the same 110-km Behrmann cell
lat = 90 - cube.grow / 2 - 0.25; lon = cube.gcol / 2 - 180 + 0.25
print('ea cells:', set(pc.ea_cell(lat.values, lon.values)))
traits = pd.DataFrame({'species': ['A a', 'B b', 'C c', 'D d', 'F f'], 'z': [1.0, 2.0, 3.0, 4.0, 10.0]})
orig = pc.load_cube
pc.load_cube = lambda group: cube
try:
    a = pc.assemblages('bees', traits, ['z'], min_species=5)
finally:
    pc.load_cube = orig
row = a.iloc[0]
rec('assemblages', 'n_species (all GBIF spp in cell, unique)', 6, row.n_species, 0)
rec('assemblages', 'n_trait (unique spp with trait)', 5, row.n_trait, 0)
rec('assemblages', 'coverage', 5 / 6, row.coverage, 1e-12)
rec('assemblages', 'mean trait (each species once)', np.mean([1, 2, 3, 4, 10]), row.z_mean, 1e-12)
la, lo = pc.ea_centroid(np.array([row.cell]))
x0, y0 = pc.behrmann_xy(la, lo); i, j = [int(v) for v in row.cell.split('_')]
rec('assemblages', 'centroid back-projects to cell centre (km)', np.array([(i + .5) * 110, (j + .5) * 110]), np.array([x0[0], y0[0]]), 1e-6)
# Behrmann cells are equal-area: area of a 110 x 110 km projected square = 12100 km^2 at any latitude
def cell_area_km2(j):
    y1, y2 = j * 110, (j + 1) * 110; phi0 = np.deg2rad(30)
    s1, s2 = np.clip(np.array([y1, y2]) * np.cos(phi0) / pc.R_EARTH, -1, 1)
    return pc.R_EARTH ** 2 * (s2 - s1) * np.deg2rad(110 / (pc.R_EARTH * np.cos(phi0)) * 180 / np.pi)
rec('assemblages', 'Behrmann cell area at 0 and 60 deg (km2)', np.array([12100, 12100]), np.array([cell_area_km2(0), cell_area_km2(int(pc.behrmann_xy(60, 0)[1] // 110))]), 1.0)

# ---------------------------------------------------------------- 4 SAR error model on a simulated spatial process
from analysis_bees_final import sar_error_lu
import libpysal, scipy.sparse as sp
lat = rng.uniform(-40, 60, 900); lon = rng.uniform(-120, 140, 900)
xk, yk = pc.behrmann_xy(lat, lon)
w = libpysal.weights.KNN(np.column_stack([xk, yk]), k=8); w.transform = 'r'; W = w.sparse.toarray()
lam_true, beta = 0.6, 0.02
ests, lams = [], []
for rep in range(6):
    u = np.linalg.solve(np.eye(len(lat)) - lam_true * W, rng.normal(size=len(lat)) * 0.3)
    d = pd.DataFrame({'lat': lat, 'lon': lon, 'abslat': np.abs(lat)}); d['y'] = 1 + beta * d.abslat + u
    r1 = pc.sar_error(d, 'y', ['abslat']); r2 = sar_error_lu(d, 'y', ['abslat'])
    ests.append(r1['table'].estimate[1]); lams.append(r1['lambda'])
    if rep == 0:
        rec('sar_error', 'LU version = spreg slope', r1['table'].estimate[1], r2['table'].estimate[1], 1e-5)
        rec('sar_error', 'LU version = spreg SE', r1['table'].se[1], r2['table'].se[1], 1e-5)
        rec('sar_error', 'LU version = spreg lambda', r1['lambda'], r2['lambda'], 1e-4)
        rec('sar_error', 'LU version = spreg Moran I', r1['moran_I_ols_resid'], r2['moran_I_ols_resid'], 1e-10)
rec('sar_error', 'mean slope over 6 sims (true 0.02)', beta, np.mean(ests), 0.004)
rec('sar_error', 'mean lambda over 6 sims (true 0.6)', lam_true, np.mean(lams), 0.08)
d = pd.DataFrame({'lat': lat, 'lon': lon, 'abslat': np.abs(lat)}); d['y'] = 1 + beta * d.abslat + rng.normal(size=len(lat)) * 0.3
r0 = pc.sar_error(d, 'y', ['abslat'])
rec('sar_error', "Moran's I of OLS residuals with iid errors ~ 0", 0.0, r0['moran_I_ols_resid'], 0.05)
rec('sar_error', 'lambda with iid errors ~ 0', 0.0, r0['lambda'], 0.15)

pd.DataFrame(ROWS).to_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'toolkit_tests.csv'), index=False)
print(f"{sum(r['passed'] for r in ROWS)}/{len(ROWS)} passed")
