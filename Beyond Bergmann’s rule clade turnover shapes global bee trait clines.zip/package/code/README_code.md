# Code: bees (Anthophila) — body size, hair, lightness and structural colour vs latitude

## Inputs
- **DATA** = folder with the published trait and phylogeny files (on the author's PC: `D:\sdm\new papers\idea\global dataset\PROJECT_POLLINATOR_MORPHOLOGY_LATITUDE\bees\data`). The expected sub-folders and file names are listed in the header of `analysis_bees_final.py`; download sources and DOIs are in `../README.md`.
- **SHARED** = one folder with these five files:
  - `pmla_common.py` (from this folder)
  - `cube_bees.parquet` (from `../data/`): GBIF species × 0.5° cell record counts, DOI 10.15468/dl.km56rh
  - `species_env_bees.csv` (from `../data/`): per-species latitude and climate summaries over the occupied 0.5° cells
  - `ne_110m_land.geojson` (from `../data/`): Natural Earth land polygons for the maps
  - `cell_climate_0.5deg.parquet`: WorldClim 2.1 bio1–bio19 averaged to 0.5° land cells. WorldClim data may not be redistributed, so this file is not included; rebuild it with `build_shared_inputs.py` (step 0).
- **OUT** = output folder of the analysis. Put `gbif_id_cache.json` (this folder) into OUT and use `--offline` to reproduce the GBIF usage-key resolution of the Ostwald et al. (2024) records without network access.

## Run order
0. `python3 build_shared_inputs.py --worldclim <multi-band GeoTIFF of bio1–bio19 at 5′> --cube <SHARED>/cube_bees.parquet --out <REBUILT>`
   (or `--worldclim-dir <folder with wc2.1_5m_bio_1.tif … wc2.1_5m_bio_19.tif>`). Writes `cell_climate_0.5deg.parquet` and `species_env_bees.csv`. Copy only `cell_climate_0.5deg.parquet` into SHARED: the included `species_env_bees.csv` is the table used for the published results; the rebuilt one differs for three species that are listed under two families in the GBIF table (*Hylaeus signatus*, *Lasioglossum villosulum*, *Megachile versicolor*: cell counts 3–57 lower) and in rounding. The rebuilt climate grid equals the one used for the analysis to float32 precision (maximum absolute difference 8 × 10⁻⁶ °C for bio1 and 2.4 × 10⁻⁴ mm for bio12; checked 2026-09-30).
1. `python3 analysis_bees_final.py --data <DATA> --shared <SHARED> --out <OUT> --offline`
   Matches all trait sources to GBIF names, builds the species table, fits every species-, specimen- and assemblage-level model and writes `<OUT>/all_models.csv` (= Table S1), `aic_latitude_vs_climate.csv`, `assemblage_coverage.csv`, the name-matching and coverage tables, and the analysis-ready tables in `<OUT>/data/`. About 9 minutes on 2 CPU cores.
2. `PMLA_SHARED=<SHARED> python3 figures_tables_bees.py`
   Builds `figures/Fig1–Fig6` and `FigS1–FigS5` (PNG at 300 dpi and PDF), the display tables `tables/Table1–4` and `TableS2–S9`, and copies them to `package/supplementary/`.
3. `PMLA_SHARED=<SHARED> python3 table1_package_bees.py`
   Builds `tables/Table1_datasets.csv` and fills `package/code` and `package/data`.
4. Optional: `python3 key_numbers.py` prints key model rows with their full-precision values (`key_numbers.txt`); `PMLA_SHARED=<SHARED> python3 test_toolkit.py` tests `tree_vcv`, `pgls`, `assemblages` and `sar_error` and the fast variants on simulated data with known answers and writes `toolkit_tests.csv` (32 of 32 checks pass).

Final fix (30 September 2026): `figures_tables_bees.py` was restyled (larger fonts, legends above the panels, the 80° N map gridline dropped)
so that all figure text is at least 7 pt at print size; only styling changed (all display and supplementary tables are byte-identical).

Steps 2–4 expect this layout: `<paper>/analysis/` (the scripts, with the outputs of step 1 in `analysis/results/`), `<paper>/figures/`, `<paper>/tables/` and `<paper>/package/`. `PMLA_SHARED` defaults to the container path used for the published run (`/home/claude/pmla/shared`).

## Key settings
- **Species filter:** at least 3 occupied 0.5° cells (integer-degree coordinates removed from the GBIF table).
- **Latitude:** median absolute latitude of the occupied cells (sensitivity analysis: absolute mid-range latitude).
- **Traits:** ITD, body length and hairiness are log10-transformed. ITD is the mean of the log10 source values (EuPollTrait, with BeeFunc only where EuPollTrait lacks the species; Ostwald et al. 2024 compilation, averaged per study and then across studies; Kendall et al. 2019 female specimens).
- **Assemblages:** 110-km Behrmann equal-area cells with at least 5 species with trait data. Coverage = species with the trait / all GBIF bee species in the cell.
- **SAR:** error model fitted by maximum likelihood; k = 8 nearest neighbours on Behrmann x/y in km; row-standardised weights.
- **LMM:** genus random intercept plus family fixed effects (REML for estimates, ML for AIC). Optimisers are tried in the order lbfgs, powell, nm, bfgs; the first converged fit with finite SEs is kept. Fitted only to subsets with at least five genera.
- **PGLS:** Pagel's λ fitted by maximum likelihood (grid 0–1, step 0.05, refined to 0.01) on the Henríquez-Piskulich et al. (2024) chronogram with tips matched to GBIF names; Brownian covariance scaled by its mean diagonal. Fitted to subsets with at least 15 species in the tree (more than 30 for structural colour).
- **GEE (structural colour):** logit link, exchangeable correlation within genera (at least ten genera).
- **Randomness:** the analysis has no stochastic steps; the simulation tests use the seed 20260930.

## Software (container, 2026-09-30)
Python 3.11.15, numpy 2.4.4, pandas 3.0.2, scipy 1.17.1, statsmodels 0.15.0, libpysal 4.14.1, spreg 1.9.0, esda 2.9.0, dendropy 5.1.0, matplotlib 3.10.9, pyreadr 0.5.7, pyarrow 25.0.1, rasterio 1.4.4 (step 0 only).
