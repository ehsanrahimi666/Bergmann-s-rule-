#!/usr/bin/env python3
"""build_shared_inputs.py -- rebuilds the two shared inputs of analysis_bees_final.py that are not redistributed
in the package (WorldClim data may not be redistributed without permission):

  cell_climate_0.5deg.parquet  WorldClim 2.1 bio1-bio19 (5 arc-min, 1970-2000) averaged to 0.5-degree cells;
                               land cells only (at least one 5' land pixel); columns grow, gcol, land_frac,
                               bio1..bio19, lat, lon (cell centre)
  species_env_bees.csv         per-species latitude and climate summary over the occupied 0.5-degree cells of the
                               GBIF grid table (cube_bees.parquet, DOI 10.15468/dl.km56rh)

Cell indices follow the GBIF download: gcol = floor((lon + 180) * 2), grow = floor((90 - lat) * 2).

Run:  python3 build_shared_inputs.py --worldclim <multi-band GeoTIFF of bio1..bio19 at 5'> --cube <cube_bees.parquet>
                                     --out <SHARED folder>   [--check <folder with reference copies>]
The WorldClim 2.1 bioclimatic variables at 5' are available from https://www.worldclim.org/data/worldclim21.html
(19 single-band files wc2.1_5m_bio_1.tif ... wc2.1_5m_bio_19.tif; pass them with --worldclim-dir instead of --worldclim).
"""
import os, argparse, glob, re
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--worldclim', help='multi-band GeoTIFF, bands = bio1..bio19')
ap.add_argument('--worldclim-dir', help='folder with wc2.1_5m_bio_1.tif ... wc2.1_5m_bio_19.tif')
ap.add_argument('--cube', required=True)
ap.add_argument('--out', required=True)
ap.add_argument('--check', help='folder with reference cell_climate_0.5deg.parquet and species_env_bees.csv')
A = ap.parse_args()
import rasterio

# ------------------------------------------------------------------ 1 WorldClim 5' -> 0.5-degree cells
def bands():
    if A.worldclim:
        with rasterio.open(A.worldclim) as r:
            assert r.count == 19 and r.width == 4320 and r.height == 2160, (r.count, r.width, r.height)
            for b in range(1, 20):
                yield b, r.read(b).astype('float64'), r.nodata
    else:
        fs = {int(re.search(r'bio_(\d+)\.tif$', f).group(1)): f for f in glob.glob(os.path.join(A.worldclim_dir, '*bio_*.tif'))}
        for b in range(1, 20):
            with rasterio.open(fs[b]) as r:
                assert r.width == 4320 and r.height == 2160
                yield b, r.read(1).astype('float64'), r.nodata

cols = {}
for b, a, nod in bands():
    if nod is not None and np.isfinite(nod): a[a == nod] = np.nan
    blk = a.reshape(360, 6, 720, 6)                      # 6 x 6 pixels of 5' per 0.5-degree cell
    valid = np.isfinite(blk)
    n = valid.sum(axis=(1, 3))
    s = np.where(valid, blk, 0.0).sum(axis=(1, 3))
    with np.errstate(invalid='ignore', divide='ignore'): cols[f'bio{b}'] = np.where(n > 0, s / n, np.nan)
    if b == 1: cols['land_frac'] = n / 36.0
grow, gcol = np.meshgrid(np.arange(360), np.arange(720), indexing='ij')
cc = pd.DataFrame({'grow': grow.ravel(), 'gcol': gcol.ravel(), 'land_frac': cols['land_frac'].ravel(),
                   **{f'bio{b}': cols[f'bio{b}'].ravel() for b in range(1, 20)}})
cc = cc[cc.land_frac > 0].reset_index(drop=True)
cc['lat'] = 90 - (cc.grow + 0.5) / 2.0
cc['lon'] = -180 + (cc.gcol + 0.5) / 2.0
os.makedirs(A.out, exist_ok=True)
cc.to_parquet(os.path.join(A.out, 'cell_climate_0.5deg.parquet'), index=False)
print('cell_climate_0.5deg.parquet:', len(cc), 'land cells')

# ------------------------------------------------------------------ 2 species latitude and climate summaries
cube = pd.read_parquet(A.cube)
occ = cube.groupby(['species', 'gcol', 'grow'], as_index=False).agg(n=('n', 'sum'))
fam = cube.groupby('species').agg(family=('family', 'first'), genus=('genus', 'first'))
occ['lat'] = 90 - (occ.grow + 0.5) / 2.0
occ['lon'] = -180 + (occ.gcol + 0.5) / 2.0
occ = occ.merge(cc[['grow', 'gcol', 'bio1', 'bio4', 'bio12', 'bio15']], on=['grow', 'gcol'], how='left')
g = occ.groupby('species')
se = pd.DataFrame({'n_cells': g.size(), 'n_records': g.n.sum(), 'abslat_median': g.lat.apply(lambda v: np.median(np.abs(v))),
                   'lat_median': g.lat.median(), 'lat_q05': g.lat.quantile(0.05), 'lat_q95': g.lat.quantile(0.95),
                   'lat_mid': g.lat.agg(lambda v: (v.min() + v.max()) / 2), 'frac_north': g.lat.agg(lambda v: (v > 0).mean()),
                   'bio1_mean': g.bio1.mean(), 'bio4_mean': g.bio4.mean(), 'bio12_mean': g.bio12.mean(), 'bio15_mean': g.bio15.mean()})
se = fam.join(se).reset_index()
se.to_csv(os.path.join(A.out, 'species_env_bees.csv'), index=False)
print('species_env_bees.csv:', len(se), 'species')

# ------------------------------------------------------------------ 3 optional comparison with reference copies
if A.check:
    ref = pd.read_parquet(os.path.join(A.check, 'cell_climate_0.5deg.parquet'))
    m = ref.merge(cc, on=['grow', 'gcol'], suffixes=('_ref', ''))
    print('cells: reference', len(ref), 'rebuilt', len(cc), 'matched', len(m))
    for c in ['land_frac', 'bio1', 'bio5', 'bio12', 'lat', 'lon']:
        print(f'  {c}: max abs diff {np.nanmax(np.abs(m[c + "_ref"] - m[c])):.3g}')
    rs = pd.read_csv(os.path.join(A.check, 'species_env_bees.csv'))
    m = rs.merge(se, on='species', suffixes=('_ref', ''))
    print('species: reference', len(rs), 'rebuilt', len(se), 'matched', len(m))
    for c in ['n_cells', 'n_records', 'abslat_median', 'lat_mid', 'frac_north', 'bio1_mean', 'bio12_mean']:
        print(f'  {c}: max abs diff {np.nanmax(np.abs(m[c + "_ref"] - m[c])):.3g}')
