#!/usr/bin/env python3
"""key_numbers.py -- prints the numbers quoted in RESULTS_BRIEF.md from analysis/results/all_models.csv (so every quoted
number can be traced to one row). Output: analysis/key_numbers.txt"""
import os, json, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); RES = os.path.join(HERE, 'results')
M = pd.read_csv(os.path.join(RES, 'all_models.csv'), low_memory=False)
out = []
def P(p): return 'p < 0.001' if p < 0.001 else f'p = {p:.3f}'
def line(level, trait, subset, model, term, formula=None, label=None):
    d = M[(M.level == level) & (M.trait == trait) & (M.subset == subset) & (M.model == model) & (M.term == term)]
    if formula is not None: d = d[d.predictor == formula]
    if not len(d): out.append(f'MISSING {level}|{trait}|{subset}|{model}|{term}|{formula}'); return
    r = d.iloc[0]
    s = f'{label or ""} [{level}|{trait}|{subset}|{model}|{r.predictor}|{term}] n={int(r.n)}: b={r.estimate:.5g} (SE {r.se:.3g}); {r.unit}: {r.slope_unit:+.4g} ± {r.se_unit:.3g} (95% CI {r.ci_lo_unit:.4g} to {r.ci_hi_unit:.4g}), {P(r.p)}'
    if np.isfinite(r.get('pct_change_unit', np.nan)): s += f'; % change {r.pct_change_unit:+.2f} ({r.pct_ci_lo:.2f} to {r.pct_ci_hi:.2f})'
    for c, lab in [('std_effect', 'std'), ('pagel_lambda', 'lambda'), ('sar_lambda', 'SAR lambda'), ('moran_I_ols', "Moran's I OLS"), ('moran_I_sar', "Moran's I SAR"),
                   ('pseudo_r2', 'pseudo-R2'), ('r2', 'R2'), ('median_coverage', 'median coverage'), ('genus_var', 'genus var'), ('dAIC_vs_linear', 'dAIC vs linear'),
                   ('vertex_deg', 'vertex'), ('prevalence', 'prevalence'), ('optimizer', 'optimizer')]:
        v = r.get(c, np.nan)
        if isinstance(v, str) or (isinstance(v, (float, int, np.floating)) and np.isfinite(v)): s += f'; {lab} {v:.3g}' if not isinstance(v, str) else f'; {lab} {v}'
    out.append(s)
out.append('== SPECIES ITD')
for mod in ['OLS', 'LMM', 'PGLS']:
    for t in ['abslat_median', 'bio1_mean']: line('species', 'log_itd', 'all', mod, t)
for m, t in [('OLS quadratic', 'abslat_c2'), ('LMM quadratic (ML)', 'abslat_c2'), ('PGLS quadratic', 'abslat_c2')]: line('species', 'log_itd', 'all', m, t)
for sub in ['N hemisphere (>=90% cells N)', 'S hemisphere (>=90% cells S)', 'females only (no BeeFunc/unknown sex)', 'no eusocial species', 'no Bombus', 'no brood parasites', 'no introduced',
            '>=10 cells', '>=2 ITD sources', 'EuPollTrait/BeeFunc value only', 'Ostwald 2024 value only', 'first-pass Ostwald name assignment', 'lat_mid instead of median',
            'W Palaearctic species', 'W Palaearctic species, females only', 'Nearctic species', 'Nearctic species, no Bombus', 'Nearctic species, females only', 'Neotropical species']:
    for mod in ['LMM', 'PGLS']:
        line('species', 'log_itd', sub, mod, 'abslat_median')
    line('species', 'log_itd', sub, 'PGLS', 'bio1_mean')
for mod in ['OLS', 'LMM', 'PGLS']: line('species', 'log_itd', 'hemisphere interaction', mod, 'abslat_x_south')
for mod in ['OLS', 'PGLS']: line('species', 'log_itd', 'lifestyle interaction (eusocial vs rest)', mod, 'abslat_x_eus')
out.append('== SPECIES other traits')
for y in ['log_blen', 'lightness', 'pilosity', 'log_hairiness_eu']:
    for mod in ['OLS', 'LMM', 'PGLS']:
        for t in ['abslat_median', 'bio1_mean']: line('species', y, 'all', mod, t)
line('species', 'log_hairiness_eu', 'no Bombus', 'PGLS', 'abslat_median'); line('species', 'log_hairiness_eu', 'no Bombus', 'LMM', 'abslat_median')
out.append('== STRUCTURAL COLOUR species')
for sub, t in [('HP2026 own latitudes (all 2,001 names)', 'abslat_hp'), ('HP2026 own climate (all names)', 'mean_annualt_data'), ('all', 'abslat_median'), ('all', 'bio1_mean'),
               ('female structural colour only', 'abslat_median'), ('no Bombus', 'abslat_median'), ('no introduced', 'abslat_median'), ('N hemisphere (>=90% cells N)', 'abslat_median'),
               ('S hemisphere (>=90% cells S)', 'abslat_median')] + [(f'family: {f}', 'abslat_median') for f in ['Apidae', 'Halictidae', 'Andrenidae', 'Megachilidae', 'Colletidae', 'Melittidae']]:
    for mod in ['GLM logit', 'GEE logit (genus clusters, exchangeable)', 'PGLS linear probability', 'GEE logit (family clusters)']:
        if mod == 'GEE logit (family clusters)' and sub != 'all': continue
        line('species', 'struc', sub, mod, t)
line('species', 'struc', 'all', 'GLM logit quadratic', 'abslat_c2')
out.append('== SPECIMENS')
for y in ['lightness', 'pilosity']:
    for t in ['abslat', 'bio1', 'bio5', 'bio12']:
        for mod in ['OLS', 'OLS + family', 'LMM']: line('specimen', y, 'Ostwald 2025 females', mod, t)
    for h in ['N', 'S']:
        for mod in ['OLS', 'LMM']: line('specimen', y, f'{h} hemisphere specimens', mod, 'abslat')
out.append('== ASSEMBLAGES')
for y in ['log_itd', 'log_blen', 'struc', 'lightness', 'pilosity', 'log_hairiness_eu']:
    for f, t in [('abslat', 'abslat'), ('bio1', 'bio1'), ('bio1 + bio12', 'bio1'), ('abslat + bio12', 'abslat')]: line('assemblage', y, 'main (>=5 spp)', 'SAR error', t, f)
    line('assemblage', y, 'main (>=5 spp)', 'SAR error quadratic', 'abslat_c2')
    for sub in ['>=10 spp', 'coverage >=0.3', 'coverage >=0.5', 'no introduced', 'no Bombus (own cells)', 'N hemisphere cells', 'S hemisphere cells',
                'region: W Palaearctic', 'region: Nearctic', 'region: Neotropics', 'region: Tropics (|lat|<23.4)']:
        line('assemblage', y, sub, 'SAR error', 'abslat', 'abslat')
for sub in ['females-only ITD', 'first-pass Ostwald names', 'no eusocial species']: line('assemblage', 'log_itd', sub, 'SAR error', 'abslat', 'abslat')
out.append('== BOMBUS mechanism (same cells)')
for sub, y, f, t in [('same cells: all bees', 'log_itd', 'abslat', 'abslat'), ('same cells: without Bombus', 'log_itd', 'abslat', 'abslat'),
                     ('same cells: all bees', 'log_itd', 'bio1', 'bio1'), ('same cells: without Bombus', 'log_itd', 'bio1', 'bio1'),
                     ('same cells: all bees', 'log_itd', 'bshare_all', 'bshare_all'), ('same cells: all bees', 'log_itd', 'abslat + bshare_all', 'abslat'),
                     ('same cells: all bees', 'log_itd', 'abslat + bshare_all', 'bshare_all'), ('same cells: all bees', 'log_itd', 'abslat + bshare_trait', 'abslat'),
                     ('same cells: Bombus share (all GBIF spp)', 'bombus_share', 'abslat', 'abslat'), ('same cells: Bombus share (ITD spp)', 'bombus_share', 'abslat', 'abslat'),
                     ('same cells: all minus no-Bombus mean', 'log_itd', 'abslat', 'abslat'),
                     ('same cells: all bees (interaction)', 'log_itd', 'abslat * bshare_all', 'abslat'), ('same cells: all bees (interaction)', 'log_itd', 'abslat * bshare_all', 'abslat_x_bshare'),
                     ('Bombus only (>=5 spp)', 'log_itd', 'abslat', 'abslat'), ('Bombus only (>=5 spp)', 'log_itd', 'bio1', 'bio1'), ('Bombus only (>=3 spp)', 'log_itd', 'abslat', 'abslat'),
                     ('same cells as no-Bombus', 'log_hairiness_eu', 'abslat', 'abslat'), ('no Bombus (same cells)', 'log_hairiness_eu', 'abslat', 'abslat'),
                     ('Europe: all bees + Bombus share', 'log_hairiness_eu', 'abslat + bshare_all', 'abslat'), ('Europe: all bees + Bombus share', 'log_hairiness_eu', 'abslat + bshare_all', 'bshare_all'),
                     ('same cells as no-Bombus', 'struc', 'abslat', 'abslat'), ('no Bombus (same cells)', 'struc', 'abslat', 'abslat')]:
    line('assemblage', y, sub, 'SAR error', t, f)
for sub in ['genus: Bombus', 'genus: Bombus social (no Psithyrus)', 'genus: Bombus no introduced']:
    for mod in ['OLS', 'PGLS']:
        for t in ['abslat_median', 'bio1_mean']: line('species', 'log_itd', sub, mod, t)
out.append('== FAMILY / GENUS')
for f in ['Apidae', 'Halictidae', 'Andrenidae', 'Megachilidae', 'Colletidae', 'Melittidae']:
    for mod in ['OLS', 'LMM', 'PGLS']: line('species', 'log_itd', f'family: {f}', mod, 'abslat_median')
    line('species', 'log_itd', f'family: {f}', 'PGLS', 'bio1_mean')
    line('assemblage', 'log_itd', f'family: {f}', 'SAR error', 'abslat', 'abslat')
    line('assemblage', 'struc', f'family: {f}', 'SAR error', 'abslat', 'abslat')
gens = sorted({s.replace('genus: ', '') for s in M.subset.unique() if isinstance(s, str) and s.startswith('genus: ') and s.count(' ') == 1})
for g in gens:
    for mod in ['OLS', 'PGLS']: line('species', 'log_itd', f'genus: {g}', mod, 'abslat_median')
    line('assemblage', 'log_itd', f'genus: {g}', 'SAR error', 'abslat', 'abslat')
for cl in ['eusocial', 'solitary/other', 'brood parasite']:
    for mod in ['LMM', 'PGLS']: line('species', 'log_itd', f'lifestyle: {cl}', mod, 'abslat_median')
    line('assemblage', 'log_itd', f'lifestyle: {cl}', 'SAR error', 'abslat', 'abslat')
for cl in ['eusocial', 'solitary', 'parasitic']:
    for mod in ['OLS', 'LMM', 'PGLS']: line('species', 'log_itd', f'Europe sociality (EuPollTrait): {cl}', mod, 'abslat_median')
open(os.path.join(HERE, 'key_numbers.txt'), 'w').write('\n'.join(out))
print('\n'.join(out))
