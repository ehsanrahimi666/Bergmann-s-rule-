"""pmla_common.py -- shared helpers for the pollinator morphology x latitude analyses.

Inputs prepared once (in /home/claude/pmla/shared):
  cube_<group>.parquet         species x 0.5-deg cell GBIF records (integer-degree coordinates removed)
  species_env_<group>.csv      per-species latitude + climate summary over occupied 0.5-deg cells
  cell_climate_0.5deg.parquet  WorldClim 2.1 bio1-bio19 averaged to 0.5-deg cells (land cells)
  ne_110m_land.geojson         Natural Earth land polygons for maps
Groups: butterflies, moths, bees, hoverflies.

Conventions: latitude predictors are ABSOLUTE latitude (degrees from the equator);
size traits are log10-transformed before modelling; assemblages use a Behrmann equal-area
grid (default 110 km, as in Krampe et al. 2026 / Stelbrink et al. 2019)."""
import json, os, re, warnings
import numpy as np, pandas as pd
warnings.filterwarnings('ignore')
SHARED = '/home/claude/pmla/shared'
R_EARTH = 6371.0072
BUTTERFLY_FAMS = {'Papilionidae', 'Pieridae', 'Nymphalidae', 'Lycaenidae', 'Riodinidae', 'Hesperiidae', 'Hedylidae'}

# ---------------------------------------------------------------- names
def clean_name(s):
    """'Pieris rapae (Linnaeus, 1758)' / 'Pieris_rapae' / 'pieris rapae ssp' -> 'Pieris rapae'."""
    if s is None or (isinstance(s, float) and np.isnan(s)): return None
    s = re.sub(r'[_]+', ' ', str(s)).strip()
    s = re.sub(r'\s*\(.*?\)', '', s)
    t = [x for x in re.split(r'\s+', s) if x]
    if len(t) < 2: return None
    g, sp = t[0], t[1]
    if not re.match(r'^[A-Za-z][a-z-]+$', g.capitalize()) or not re.match(r'^[a-z-]+\.?$', sp.lower()): return None
    if sp.lower() in ('sp', 'sp.', 'spp', 'spp.', 'cf', 'cf.', 'aff', 'aff.'): return None
    return g.capitalize() + ' ' + sp.lower().rstrip('.')

# ---------------------------------------------------------------- distributions
def load_cube(group):
    return pd.read_parquet(os.path.join(SHARED, f'cube_{group}.parquet'))

def species_env(group):
    """Per-species table: species, family, genus, n_cells, n_records, abslat_median, lat_median,
    lat_q05, lat_q95, lat_mid, frac_north, bio1_mean (deg C), bio4_mean (temp seasonality),
    bio12_mean (annual precipitation, mm), bio15_mean (precipitation seasonality)."""
    return pd.read_csv(os.path.join(SHARED, f'species_env_{group}.csv'))

def cell_climate():
    return pd.read_parquet(os.path.join(SHARED, 'cell_climate_0.5deg.parquet'))

# ---------------------------------------------------------------- equal-area grid
def behrmann_xy(lat, lon):
    phi0 = np.deg2rad(30.0)
    x = R_EARTH * np.deg2rad(np.asarray(lon, float)) * np.cos(phi0)
    y = R_EARTH * np.sin(np.deg2rad(np.asarray(lat, float))) / np.cos(phi0)
    return x, y

def ea_cell(lat, lon, km=110.0):
    x, y = behrmann_xy(lat, lon)
    return (np.floor(x / km).astype(int).astype(str) + '_' + np.floor(y / km).astype(int).astype(str))

def ea_centroid(cell_ids, km=110.0):
    ij = np.array([c.split('_') for c in cell_ids], dtype=float)
    x, y = (ij[:, 0] + 0.5) * km, (ij[:, 1] + 0.5) * km
    phi0 = np.deg2rad(30.0)
    lon = np.rad2deg(x / (R_EARTH * np.cos(phi0)))
    lat = np.rad2deg(np.arcsin(np.clip(y * np.cos(phi0) / R_EARTH, -1, 1)))
    return lat, lon

def assemblages(group, traits, trait_cols, km=110.0, min_species=5, min_coverage=0.0, species_col='species'):
    """Assemblage (equal-area cell) means of species traits.
    traits: DataFrame with species_col + trait_cols (one row per species).
    Returns one row per cell: cell, lat, lon, abslat, n_species (all GBIF species), n_trait (species with
    trait data), coverage, <trait>_mean, <trait>_sd, bio1/bio4/bio12/bio15 (cell means)."""
    cube = load_cube(group)[['species', 'gcol', 'grow', 'n']]
    cube['lat'] = 90 - cube.grow / 2 - 0.25; cube['lon'] = cube.gcol / 2 - 180 + 0.25
    cube['cell'] = ea_cell(cube.lat.values, cube.lon.values, km)
    occ = cube[['cell', 'species']].drop_duplicates()
    tot = occ.groupby('cell').size().rename('n_species')
    tr = traits[[species_col] + list(trait_cols)].dropna(subset=list(trait_cols), how='all').rename(columns={species_col: 'species'})
    tr = tr.groupby('species', as_index=False).mean(numeric_only=True)
    m = occ.merge(tr, on='species', how='inner')
    agg = m.groupby('cell').agg(n_trait=('species', 'size'), **{f'{c}_mean': (c, 'mean') for c in trait_cols},
                                **{f'{c}_sd': (c, 'std') for c in trait_cols})
    out = agg.join(tot).reset_index()
    out['coverage'] = out.n_trait / out.n_species
    out = out[(out.n_trait >= min_species) & (out.coverage >= min_coverage)].copy()
    out['lat'], out['lon'] = ea_centroid(out.cell.values, km)
    out['abslat'] = out.lat.abs()
    cc = cell_climate(); cc['cell'] = ea_cell(cc.lat.values, cc.lon.values, km)
    clim = cc.groupby('cell')[['bio1', 'bio4', 'bio12', 'bio15']].mean()
    return out.merge(clim, left_on='cell', right_index=True, how='left')

# ---------------------------------------------------------------- models
def ols(df, y, xs):
    import statsmodels.formula.api as smf
    return smf.ols(f'{y} ~ ' + ' + '.join(xs), data=df).fit()

def sar_error(df, y, xs, k=8):
    """Spatial simultaneous autoregressive error model (ML) with k-nearest-neighbour weights on
    equal-area coordinates. Returns dict with coefficients table, lambda, AIC, pseudo-R2, Moran's I of
    OLS residuals and its p-value."""
    import libpysal, spreg
    from esda.moran import Moran
    d = df.dropna(subset=[y] + xs).copy()
    x_, y_ = behrmann_xy(d.lat.values, d.lon.values)
    w = libpysal.weights.KNN(np.column_stack([x_, y_]), k=k); w.transform = 'r'
    Y = d[[y]].values; X = d[xs].values
    o = spreg.OLS(Y, X, w=w, name_y=y, name_x=xs, spat_diag=False)
    mi = Moran(o.u.flatten(), w, permutations=0)
    m = spreg.ML_Error(Y, X, w=w, name_y=y, name_x=xs)
    names = ['CONSTANT'] + xs + ['lambda']
    tab = pd.DataFrame({'term': names, 'estimate': m.betas.flatten(), 'se': m.std_err, 'z': [z[0] for z in m.z_stat],
                        'p': [z[1] for z in m.z_stat]})
    return {'table': tab, 'lambda': float(m.lam), 'aic': float(m.aic), 'pseudo_r2': float(m.pr2), 'n': int(m.n),
            'ols_r2': float(o.r2), 'moran_I_ols_resid': float(mi.I), 'moran_p': float(mi.p_norm)}

def read_tree(path, schema=None):
    import dendropy
    if schema is None:
        head = open(path, encoding='utf-8', errors='ignore').read(200).lower()
        schema = 'nexus' if '#nexus' in head else 'newick'
    return dendropy.Tree.get(path=path, schema=schema, preserve_underscores=True, rooting='default-rooted')

def tree_vcv(tree, keep):
    """Brownian covariance (shared root-to-MRCA path length) for tips whose clean_name is in keep.
    Returns (names, V). Tips are pruned to one per clean name."""
    tips = {}
    for nd in tree.leaf_node_iter():
        nm = clean_name(nd.taxon.label if nd.taxon else None)
        if nm and nm in keep and nm not in tips: tips[nm] = nd
    names = list(tips); idx = {id(tips[n]): i for i, n in enumerate(names)}
    n = len(names); V = np.zeros((n, n))
    depth = {}
    for nd in tree.preorder_node_iter():
        el = nd.edge.length or 0.0
        depth[id(nd)] = (depth[id(nd.parent_node)] if nd.parent_node else 0.0) + (el if nd.parent_node else 0.0)
    below = {}
    for nd in tree.postorder_node_iter():
        if nd.is_leaf():
            below[id(nd)] = [idx[id(nd)]] if id(nd) in idx else []
            if id(nd) in idx: V[idx[id(nd)], idx[id(nd)]] = depth[id(nd)]
        else:
            ch = [below.pop(id(c)) for c in nd.child_node_iter()]
            dd = depth[id(nd)]
            for a in range(len(ch)):
                for b in range(a + 1, len(ch)):
                    if ch[a] and ch[b]:
                        V[np.ix_(ch[a], ch[b])] = dd; V[np.ix_(ch[b], ch[a])] = dd
            below[id(nd)] = [i for c in ch for i in c]
    return names, V

def pgls(df, y, xs, tree, species_col='species', lambdas=np.linspace(0, 1, 21)):
    """PGLS with Pagel's lambda estimated by maximum likelihood (grid + refinement).
    Returns dict: table (estimate, se, t, p), lambda, logLik, n."""
    from scipy import stats
    d = df.dropna(subset=[y] + xs).drop_duplicates(species_col).set_index(species_col)
    names, V = tree_vcv(tree, set(d.index))
    d = d.loc[names]; Y = d[y].values; X = np.column_stack([np.ones(len(d))] + [d[x].values for x in xs]); n, p = X.shape
    diag = np.diag(V).copy(); sc = diag.mean(); V = V / sc
    def fit(lam):
        C = V * lam; np.fill_diagonal(C, np.diag(V))
        L = np.linalg.cholesky(C)
        Xs = np.linalg.solve(L, X); Ys = np.linalg.solve(L, Y)
        b, *_ = np.linalg.lstsq(Xs, Ys, rcond=None); r = Ys - Xs @ b
        s2 = r @ r / n; ll = -0.5 * (n * np.log(2 * np.pi * s2) + 2 * np.sum(np.log(np.diag(L))) + n)
        cov = np.linalg.inv(Xs.T @ Xs) * (r @ r / (n - p))
        return ll, b, cov
    res = [(lam, *fit(lam)) for lam in lambdas]
    best = max(res, key=lambda t: t[1]); lam0 = best[0]
    for lam in np.clip(np.linspace(lam0 - 0.05, lam0 + 0.05, 11), 0, 1):
        r_ = (lam, *fit(lam))
        if r_[1] > best[1]: best = r_
    lam, ll, b, cov = best; se = np.sqrt(np.diag(cov)); t = b / se; pv = 2 * stats.t.sf(np.abs(t), n - p)
    ll0 = fit(0.0)[0] if lam > 0 else ll
    tab = pd.DataFrame({'term': ['Intercept'] + xs, 'estimate': b, 'se': se, 't': t, 'p': pv})
    return {'table': tab, 'lambda': float(lam), 'logLik': float(ll), 'n': int(n),
            'LR_lambda_vs_0': float(2 * (ll - ll0))}

def mixed(df, y, xs, group='genus', fixed_family=True):
    """Linear mixed model with random intercepts for genus (taxonomic non-independence) and optional
    family fixed effects."""
    import statsmodels.formula.api as smf
    d = df.dropna(subset=[y] + xs + [group]).copy()
    f = f'{y} ~ ' + ' + '.join(xs) + (' + C(family)' if fixed_family and 'family' in d and d.family.nunique() > 1 else '')
    return smf.mixedlm(f, d, groups=d[group]).fit(reml=True, method='lbfgs')

# ---------------------------------------------------------------- plotting
def land_polygons():
    g = json.load(open(os.path.join(SHARED, 'ne_110m_land.geojson'), encoding='utf-8'))
    polys = []
    for f in g['features']:
        geom = f['geometry']; cs = geom['coordinates']
        for poly in (cs if geom['type'] == 'MultiPolygon' else [cs]): polys.append(np.array(poly[0]))
    return polys

def world_map(ax, df, col, cmap='viridis', title=None, size=4, vmin=None, vmax=None, label=None):
    import matplotlib.pyplot as plt
    for p in land_polygons(): ax.fill(p[:, 0], p[:, 1], color='#e6e6e6', lw=0, zorder=0)
    q = df[col].quantile([0.02, 0.98]).values
    sc = ax.scatter(df.lon, df.lat, c=df[col], s=size, marker='s', cmap=cmap, lw=0,
                    vmin=q[0] if vmin is None else vmin, vmax=q[1] if vmax is None else vmax, zorder=1)
    ax.set_xlim(-180, 180); ax.set_ylim(-60, 85); ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values(): s.set_visible(False)
    if title: ax.set_title(title, fontsize=10, loc='left')
    cb = plt.colorbar(sc, ax=ax, shrink=0.6, pad=0.01); cb.set_label(label or col, fontsize=8); cb.ax.tick_params(labelsize=7)
    return sc

def lat_plot(ax, df, x, y, xlabel='Absolute latitude (°)', ylabel=None, bins=10, color='#2a6f97', fit=True, alpha=0.25, s=6):
    d = df.dropna(subset=[x, y])
    ax.scatter(d[x], d[y], s=s, alpha=alpha, color=color, lw=0)
    br = np.linspace(d[x].min(), d[x].max(), bins + 1); d = d.assign(_b=pd.cut(d[x], br, include_lowest=True))
    g = d.groupby('_b', observed=True)[y].agg(['mean', 'sem', 'size']); mid = [iv.mid for iv in g.index]
    ax.errorbar(mid, g['mean'], yerr=1.96 * g['sem'], fmt='o-', color='k', ms=3, lw=1, capsize=2)
    if fit and len(d) > 3:
        b = np.polyfit(d[x], d[y], 1); xx = np.linspace(d[x].min(), d[x].max(), 50); ax.plot(xx, np.polyval(b, xx), color='#c1121f', lw=1.2)
    ax.set_xlabel(xlabel, fontsize=9); ax.set_ylabel(ylabel or y, fontsize=9); ax.tick_params(labelsize=8)
    return ax

def save(fig, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=300, bbox_inches='tight'); fig.clf()
