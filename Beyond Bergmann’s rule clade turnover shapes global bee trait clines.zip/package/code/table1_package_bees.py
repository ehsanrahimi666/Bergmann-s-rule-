#!/usr/bin/env python3
"""table1_package_bees.py -- Table 1 (datasets) and the per-paper package folder (code/, data/, README files).
Run after analysis_bees_final.py and figures_tables_bees.py."""
import os, json, shutil, glob
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
RES = os.path.join(HERE, 'results'); RD = os.path.join(RES, 'data')
TAB = os.path.join(ROOT, 'tables'); PKG = os.path.join(ROOT, 'package')
SHARED = os.environ.get('PMLA_SHARED', '/home/claude/pmla/shared')
nm = pd.read_csv(os.path.join(RES, 'name_matching_by_source.csv'))
SP = pd.read_csv(os.path.join(RD, 'species_traits_latitude_climate_analysed.csv'))
ALL = pd.read_csv(os.path.join(RD, 'species_traits_all_matched.csv'))
tree = json.load(open(os.path.join(RES, 'tree_info.json'))); spec = json.load(open(os.path.join(RES, 'specimen_info.json')))
M = pd.read_csv(os.path.join(RES, 'all_models.csv'), low_memory=False)
cube = pd.read_parquet(os.path.join(SHARED, 'cube_bees.parquet'))
def src(key): return nm[nm.source.str.startswith(key)].iloc[0]
itd_used = SP.log_itd.notna()
def n_pgls(trait):
    r = M[(M.level == 'species') & (M.trait == trait) & (M.subset == 'all') & (M.model.isin(['PGLS', 'PGLS linear probability'])) & (M.term == 'abslat_median')]
    return int(r.n.iloc[0]) if len(r) else ''
rows = [
 dict(Dataset='GBIF occurrence records, Anthophila (0.5° species × cell grid)', Reference='GBIF.org (2026)', DOI='10.15468/dl.km56rh', Licence='CC BY-NC 4.0',
      Content='Georeferenced occurrences aggregated to 0.5° cells (integer-degree coordinates removed)', Extent='Global',
      n_records=f"{int(cube.n.sum()):,} records; {cube[['gcol','grow']].drop_duplicates().shape[0]:,} occupied 0.5° cells", n_names=f'{cube.species.nunique():,} species',
      n_species_matched='—', n_species_analysed=f"{int((SP.n_cells >= 3).sum()):,} species with a trait and ≥3 cells", Role='Species latitude/climate summaries; assemblage composition and coverage'),
 dict(Dataset='WorldClim 2.1 bioclimatic variables', Reference='Fick & Hijmans (2017)', DOI='10.1002/joc.5086', Licence='Free for academic use (WorldClim terms)',
      Content='bio1, bio4, bio5, bio12 at 5′, averaged to 0.5° land cells', Extent='Global land', n_records='95,447 land cells', n_names='—', n_species_matched='—', n_species_analysed='—',
      Role='Temperature/precipitation predictors (species range means, cell means, specimen cells)'),
 dict(Dataset='EuPollTrait (European bee and hoverfly traits)', Reference='Miličić et al. (2026)', DOI='10.1038/s41597-026-07513-8; data 10.5281/zenodo.18032357', Licence='CC BY 4.0',
      Content='Female ITD (workers for eusocial species), female hairiness index, sociality', Extent='Europe',
      n_records=f"{int(src('EuPollTrait').n_records):,} bee species rows", n_names=f"{int(src('EuPollTrait').n_names):,}", n_species_matched=f"{int(src('EuPollTrait').n_gbif_species):,}",
      n_species_analysed=f"ITD {int((SP.itd_eu.notna() & itd_used).sum()):,}; hairiness {int(SP.log_hairiness_eu.notna().sum()):,}", Role='ITD (main European source), hairiness index, sociality classes'),
 dict(Dataset='BeeFunc (French bee traits)', Reference='Aubouin et al. (2025)', DOI='10.1038/s41597-025-05626-0', Licence='CC BY 4.0 (article); database terms in source',
      Content='ITD (sex/caste not recorded), sociality', Extent='France',
      n_records=f"{int(src('BeeFunc').n_records):,} ITD records", n_names=f"{int(src('BeeFunc').n_names):,}", n_species_matched=f"{int(src('BeeFunc').n_gbif_species):,}",
      n_species_analysed=f"ITD fill-in for {int((SP.itd_bf.notna() & SP.itd_eu.isna() & itd_used).sum()):,}", Role='ITD fill-in only where EuPollTrait lacks a species; excluded from females-only ITD'),
 dict(Dataset='Bee functional-trait compilation (Ostwald et al.)', Reference='Ostwald (2024), Zenodo release v1.3.0', DOI='10.5281/zenodo.13366989', Licence='MIT',
      Content='ITD (28 studies) and body length (6 studies): species means, study means and single specimens; records of males, mixed sexes and queens excluded', Extent='Global compilation, mostly N America and Europe',
      n_records=f"ITD {int(src('Ostwald et al. 2024 compilation: ITD').n_records):,}; body length {int(src('Ostwald et al. 2024 compilation: body length').n_records):,}",
      n_names=f"{int(src('Ostwald et al. 2024 compilation: ITD').n_names):,} (ITD)", n_species_matched=f"{int(src('Ostwald et al. 2024 compilation: ITD').n_gbif_species):,} (ITD)",
      n_species_analysed=f"ITD {int((SP.log_itd_ost.notna() & itd_used).sum()):,}; body length {int(SP.log_bl_ost.notna().sum()):,}", Role='ITD and body length (study means averaged on log10 scale)'),
 dict(Dataset='pollimetry specimen data', Reference='Kendall et al. (2019)', DOI='10.1002/ece3.4835; code 10.5281/zenodo.1313905', Licence='Open (repository licence)',
      Content='ITD and body length of female bee specimens', Extent='Europe, N America, Australasia, S America (4 regions)',
      n_records=f"{int(src('Kendall').n_records):,} female specimens", n_names=f"{int(src('Kendall').n_names):,}", n_species_matched=f"{int(src('Kendall').n_gbif_species):,}",
      n_species_analysed=f"ITD {int((SP.itd_ken.notna() & itd_used).sum()):,}; body length {int(SP.bl_ken.notna().sum()):,}", Role='ITD and body length'),
 dict(Dataset='Structural colour in bees', Reference='Henríquez-Piskulich et al. (2026), data', DOI='10.5061/dryad.h70rxwdwq', Licence='CC0 (Dryad)',
      Content='Presence of structural colour (either sex; female-only column), female body length, species median latitude and climate', Extent='Global (species with literature/images)',
      n_records=f"{int(src('Henriquez').n_records):,} species", n_names=f"{int(src('Henriquez').n_names):,}", n_species_matched=f"{int(src('Henriquez').n_gbif_species):,}",
      n_species_analysed=f"structural colour {int(SP.struc.notna().sum()):,}; body length {int(SP.bl_hp.notna().sum()):,}", Role='Structural colour (binary); body length; replication with the authors’ latitudes'),
 dict(Dataset='Bee pilosity and lightness from images', Reference='Ostwald et al., Zenodo data record for “Climate explains global functional trait variation in bees”', DOI='10.5281/zenodo.15213039', Licence='CC BY 4.0',
      Content='Median brightness (lightness, 0–255) and hair-covered proportion (pilosity) of imaged female specimens with coordinates', Extent='Global, 42°S–50°N',
      n_records=f"{spec['n_records']} specimens ({spec['n_on_land_with_climate']} with valid coordinates and climate)", n_names=f"{int(src('Ostwald et al. 2025').n_names):,}",
      n_species_matched=f"{int(src('Ostwald et al. 2025').n_gbif_species):,}", n_species_analysed=f"{int(SP.lightness.notna().sum()):,} species; {spec['n_on_land_with_climate']} specimens",
      Role='Lightness and pilosity (species means; specimen-level climate models)'),
 dict(Dataset='Supermatrix phylogeny of the world’s bees (chronogram)', Reference='Henríquez-Piskulich et al. (2023), data', DOI='10.5061/dryad.80gb5mkw1', Licence='CC0 (Dryad)',
      Content='Dated ultrametric tree (treePL), 4,586 species', Extent='Global', n_records=f"{tree['n_tips']:,} tips", n_names=f"{tree['n_tips']:,}",
      n_species_matched=f"{tree['matched']:,} ({tree['exact']:,} exact, {tree['synonym']} via synonymy; {tree['duplicates']} duplicate tips dropped)",
      n_species_analysed=f"PGLS: ITD {n_pgls('log_itd')}, structural colour {n_pgls('struc')}, lightness {n_pgls('lightness')}", Role='PGLS (Pagel’s λ)'),
 dict(Dataset='Discover Life world bee checklist (TSV)', Reference='Poelen & Seltmann (2024)', DOI='10.5281/zenodo.10463762', Licence='CC0',
      Content='Accepted names, synonyms, tribes', Extent='Global', n_records='20,722 accepted; 31,889 synonym rows', n_names='20,555 unambiguous synonyms used', n_species_matched='—', n_species_analysed='—',
      Role='Name matching (synonymy) and tribe-based lifestyle classes'),
 dict(Dataset='Natural Earth 1:110m land', Reference='Natural Earth', DOI='— (naturalearthdata.com)', Licence='Public domain', Content='Land polygons', Extent='Global', n_records='—', n_names='—',
      n_species_matched='—', n_species_analysed='—', Role='Map outlines only'),
]
T1 = pd.DataFrame(rows).rename(columns={'n_records': 'n records', 'n_names': 'n names', 'n_species_matched': 'n species matched to GBIF', 'n_species_analysed': 'n species analysed (≥3 cells)'})
T1.to_csv(os.path.join(TAB, 'Table1_datasets.csv'), index=False)
print(T1[['Dataset', 'n records', 'n species matched to GBIF', 'n species analysed (≥3 cells)']].to_string())

# ------------------------------------------------------------------ package
for d in ('code', 'data', 'supplementary'): os.makedirs(os.path.join(PKG, d), exist_ok=True)
for f in ('analysis_bees_final.py', 'build_shared_inputs.py', 'figures_tables_bees.py', 'table1_package_bees.py', 'key_numbers.py', 'test_toolkit.py', 'toolkit_tests.csv'):
    if os.path.exists(os.path.join(HERE, f)): shutil.copy(os.path.join(HERE, f), os.path.join(PKG, 'code', f))
shutil.copy(os.path.join(SHARED, 'pmla_common.py'), os.path.join(PKG, 'code', 'pmla_common.py'))
shutil.copy(os.path.join(RES, 'gbif_id_cache.json'), os.path.join(PKG, 'code', 'gbif_id_cache.json'))
for f in glob.glob(os.path.join(RD, '*')): shutil.copy(f, os.path.join(PKG, 'data', os.path.basename(f)))
for f in ('name_matching_by_source.csv', 'analysed_species_by_trait.csv', 'trait_source_agreement.csv', 'ostwald2024_name_key_conflicts.csv', 'assemblage_coverage.csv',
          'aic_latitude_vs_climate.csv', 'tree_info.json', 'specimen_info.json'):
    shutil.copy(os.path.join(RES, f), os.path.join(PKG, 'data', f))
shutil.copy(os.path.join(SHARED, 'cube_bees.parquet'), os.path.join(PKG, 'data', 'cube_bees.parquet'))
for f in ('species_env_bees.csv', 'ne_110m_land.geojson'):  # shared inputs of the scripts (the WorldClim cell grid is rebuilt with build_shared_inputs.py)
    shutil.copy(os.path.join(SHARED, f), os.path.join(PKG, 'data', f))
se = pd.read_csv(os.path.join(SHARED, 'species_env_bees.csv'))
se[se.species.isin(SP.species)].to_csv(os.path.join(PKG, 'data', 'species_latitude_climate_analysed_species.csv'), index=False)
for f in os.listdir(TAB):
    if f.startswith('Table') and not f.startswith('TableS'): shutil.copy(os.path.join(TAB, f), os.path.join(PKG, 'supplementary', 'main_' + f))
print('package files:', sum(len(files) for _, _, files in os.walk(PKG)), 'size MB', round(sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(PKG) for f in fs) / 1e6, 1))
